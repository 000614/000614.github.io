import gradio as gr
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.prompts import PromptTemplate
from try_api_bd_model import try_api_bd_model
from tools_RAG_db import get_db_list
# from tools_fun import www_search_fun, chengfa_fun, rag_fun
from tools_RAG_db import calculate_mrr
from langchain_core.tools import tool
import os
from langchain_community.tools.tavily_search import TavilySearchResults
os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY")


# 记录工具调用次数的字典
show_tool_result = []
show_tool_name = []
tool_call_count = {}


@tool
def chengfa_fun(a, b):
    """
    此函数用于计算两数的乘积。

    参数:
    a: 要做乘法的第一个数。
    b: 要做乘法的第二个数。

    返回:
    c: 最终的乘积结果。
    """
    global show_tool_result, show_tool_name, tool_call_count
    tool_call_count["乘法工具"] = tool_call_count.get("乘法工具", 0) + 1
    c = str(a * b)
    show_tool_result.append(c)
    show_tool_name.append("乘法工具")
    c = "如果以下参考资料中没有能回答用户问题的内容，请告诉用户【乘法工具中并无合适资料】，再回答用户问题，以下为乘法工具调用内容【" + str(
        c) + "】"
    return c


@tool
def rag_fun(query="默认查询"):
    """
    此函数用于搜索RAG相关信息来增强生成

    参数:
    query: 用户输入的问题。
    db_name: 要查询的数据库名称。
    db_type: 要查询的数据库类型。

    返回:
    rag_result: 最终的查询结果。
    """
    global show_tool_result, show_tool_name, db_name, db_type, tool_call_count
    tool_call_count["RAG工具"] = tool_call_count.get("RAG工具", 0) + 1
    results = calculate_mrr(query, db_type, db_name)

    rag_result = [r[0] for r in results]
    show_tool_result.append(str(rag_result))
    show_tool_name.append("RAG工具")
    rag_result = "如果以下参考资料中没有能回答用户问题的内容，请告诉用户【rag知识库中并无合适资料】，再回答用户问题，以下为RAG工具调用内容【" + str(
        rag_result) + "】"
    return rag_result


@tool
def www_search_fun(query):
    """
    此函数用于链接互联网做联网查询问题

    参数:
    query: 用户输入的问题。

    返回:
    search_result: 联网查询后，最终的查询结果。
    """
    global show_tool_result, show_tool_name, tool_call_count
    tool_call_count["联网工具"] = tool_call_count.get("联网工具", 0) + 1  # 新增计数逻辑
    search_result = TavilySearchResults(max_results=2).invoke(query)
    show_tool_result.append(str(search_result))
    show_tool_name.append("联网工具")
    search_result = "如果以下参考资料中没有能回答用户问题的内容，请告诉用户【联网工具中并无合适资料】，再回答用户问题，以下为联网工具调用内容【" + str(
        search_result) + "】"
    return search_result


db_name = ""
db_type = ""


def update_db_name(selected_db):
    global db_name
    db_name = selected_db


def update_db_type(selected_db_type):
    global db_type
    db_type = selected_db_type


# 创建工具和Agent
def init_agent(temperature):
    print("开始检查model配置的api_key")
    model = try_api_bd_model("gpt-3.5-turbo")
    model = model.with_config(configurable={"llm_temperature": temperature})

    tools = [www_search_fun, chengfa_fun, rag_fun]

    prompt = PromptTemplate(
        input_variables=["input", "tools_names", "agent_scratchpad"],
        template="""你是一个智能助手，擅长借助工具回答用户的问题。当你需要获取额外信息时，可调用提供的工具.
        问题：{input}
        可用工具：{tools_names}
        {agent_scratchpad}"""
    )

    agent = create_tool_calling_agent(model, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools)


def send_message(user_input, history, tools_names, temperature):
    global show_tool_result, show_tool_name
    show_tool_result = []
    show_tool_name = []

    agent_executor = init_agent(temperature)

    resp = agent_executor.invoke({
        "input": user_input,
        "tools_names": tools_names,
    })

    if "RAG工具" in show_tool_name:
        all_not_contain = all("以下为RAG工具调用内容" not in result for result in show_tool_result)
        if all_not_contain:
            search_result = TavilySearchResults(max_results=2).invoke(user_input)
            resp = agent_executor.invoke({
                "input": user_input+"可参考的联网资料："+str(search_result),
                "tools_names": [],
            })
    print(f"resp= {resp}")

    new_history = history + [
        {
            "role": "user",
            "content": user_input
        },
        {
            "role": "assistant",
            "content": resp["output"]
        }
    ]

    # 返回聊天历史和工具结果
    return new_history, "\n".join(show_tool_result), "\n".join(show_tool_name)


def refresh_db_list():
    global db_type
    new_choices = get_db_list(db_type)
    print(f"刷新后的数据库列表: {new_choices}")
    return gr.update(choices=new_choices)


if __name__ == "__main__":
    with gr.Blocks() as demo:

        with gr.Tab("🤖 单智能体"):
            with gr.Row():

                with gr.Column(scale=3, min_width=600, elem_classes="control-card"):
                    chatbot_single = gr.Chatbot(
                        label="对话历史",
                        elem_classes="chat-container",
                        height=500,
                        type='messages'
                    )
                    with gr.Row():
                        question_input_single = gr.Textbox(
                            label="输入问题",
                            lines=3,
                            placeholder="请输入您的问题...",
                            elem_classes="gr-textbox",
                            container=False,
                            scale=5
                        )
                        with gr.Column(scale=1):
                            submit_button_single = gr.Button("🚀 发送", elem_classes="custom-button")
                            clear_btn_single = gr.Button("🧹 清空", elem_classes="custom-button")

                clear_btn_single.click(lambda: None, None, chatbot_single, queue=False)

                # 侧边控制面板
                with gr.Column(scale=1, min_width=200, elem_classes="control-card"):
                    # 新增单选框组件
                    db_type_radio = gr.Radio(
                        choices=["faiss", "chroma"],
                        label="选择数据库类型",
                        value=None,
                        elem_classes="custom-radio"
                    )

                    dataset_dropdown_single = gr.Dropdown(
                        choices=["请刷新后再选择知识库"],
                        label="选择知识库",
                        value="请刷新后再选择知识库"
                    )
                    dataset_dropdown_single.change(
                        fn=update_db_name,
                        inputs=[dataset_dropdown_single],
                        outputs=[]
                    )
                    gr.Markdown("### 选择可用工具")
                    tool_list_single = gr.CheckboxGroup(
                        choices=["联网搜索", "RAG向量数据库检索", "乘法计算"],
                        label="选择可用工具",
                        value=["联网搜索", "RAG向量数据库检索", "乘法计算"],
                        container=False
                    )
                    temperature = gr.Slider(0, 1, value=0.7, label="温度系数")
                    tool_name_result = gr.Textbox(label="已调用工具名称", interactive=False)
                    tool_result = gr.Textbox(label="工具调用结果", interactive=False)
        db_type_radio.change(
            fn=update_db_type,
            inputs=[db_type_radio],
            outputs=[]
        ).then(
            fn=refresh_db_list,
            outputs=[dataset_dropdown_single]
        )
        submit_button_single.click(
            send_message,
            inputs=[question_input_single, chatbot_single, tool_list_single, temperature],
            outputs=[chatbot_single, tool_result, tool_name_result]
        )

    demo.launch()


