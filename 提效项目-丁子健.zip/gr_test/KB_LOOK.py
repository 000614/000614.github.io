import gradio as gr
import pandas as pd
import matplotlib.pyplot as plt
from agent_one import tool_call_count
from KB_Up_Loading import get_all_dbs_count

# 中文字体设置
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定中文字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


# 动态更新工具调用可视化数据的函数
def update_tool_plot():
    from agent_one import tool_call_count

    tool_plot = None
    if tool_call_count:
        df_tool = pd.DataFrame(list(tool_call_count.items()), columns=['工具', '调用次数'])
        fig3 = create_bar_plot(df_tool, '工具', '调用次数', '工具调用分布')
        tool_plot = fig3

    return tool_plot




# 动态更新数据库调用可视化数据的函数
def update_db_plot():
    db_plot = None
    db_count = get_all_dbs_count()
    if db_count:
        data = [{'数据库类型': t, '数据库名称': n, '占用容量条数': c}
                for t, sub in db_count.items() for n, c in sub.items()]
        df_db = pd.DataFrame(data)
        df_db['数据库'] = df_db['数据库类型'] + ' - ' + df_db['数据库名称']
        fig4 = create_bar_plot(df_db, '数据库', '占用容量条数', '数据库容量分布')
        db_plot = fig4

    return db_plot


# 通用柱状图生成函数
def create_bar_plot(df, x, y, title):
    fig, ax = plt.subplots()
    df.plot.bar(x=x, y=y, ax=ax)
    ax.set_title(title)
    ax.tick_params(axis='x', rotation=45)
    fig.tight_layout()
    plt.close(fig)
    return fig


# 饼图生成函数
def create_pie_chart(df, x, y, title):
    fig, ax = plt.subplots()
    df.plot.pie(
        ax=ax,
        y=y,
        labels=df[x],
        autopct='%1.1f%%',  # 显示百分比格式
        startangle=140      # 起始角度
    )
    ax.set_title(title)
    plt.tight_layout()
    plt.close(fig)
    return fig


def update_tool_pie():
    from agent_one import tool_call_count
    if tool_call_count:
        df_tool = pd.DataFrame(list(tool_call_count.items()), columns=['工具', '调用次数'])
        fig = create_pie_chart(df_tool, '工具', '调用次数', '工具调用分布')
        return fig
    return None


# 数据库调用饼图回调
def update_db_pie():
    db_count = get_all_dbs_count()
    if db_count:
        data = [{'数据库类型': t, '数据库名称': n, '占用容量条数': c}
                for t, sub in db_count.items() for n, c in sub.items()]
        df_db = pd.DataFrame(data)
        df_db['数据库'] = df_db['数据库类型'] + ' - ' + df_db['数据库名称']
        fig = create_pie_chart(df_db, '数据库', '占用容量条数', '数据库容量分布')
        return fig
    return None


def update_tool_both():
    plot = update_tool_plot()
    pie = update_tool_pie()
    return plot, pie

def update_db_both():
    plot = update_db_plot()
    pie = update_db_pie()
    return plot, pie

if __name__ == "__main__":
    with gr.Blocks() as demo:
        with gr.Tab("📊 数据可视化") as tab:

            gr.Markdown("### 工具调用统计")
            with gr.Row():
                tool_plot = gr.Plot(label="工具调用柱状图")
                tool_pie_plot = gr.Plot(label="工具调用分布饼图")
            tool_refresh_btn = gr.Button("🔄 刷新工具数据")


            gr.Markdown("### 数据库调用统计")
            with gr.Row():
                db_plot = gr.Plot(label="数据库容量柱状图")
                db_pie_plot = gr.Plot(label="数据库容量分布饼图")
            db_refresh_btn = gr.Button("🔄 刷新数据库数据")
            tool_refresh_btn.click(
                fn=update_tool_both,
                outputs=[tool_plot, tool_pie_plot]
            )
            
            db_refresh_btn.click(
                fn=update_db_both,
                outputs=[db_plot, db_pie_plot]
            )

    demo.launch(share=False)
