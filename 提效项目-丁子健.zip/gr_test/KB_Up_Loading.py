import gradio as gr
from tools_RAG_db import create_vector_db, get_db_list, delete_db, get_all_data



def get_all_dbs_count():
    """检索所有数据库并返回结构化数据"""
    global db_count
    all_types = ["faiss", "chroma"]  # 假设支持的数据库类型
    db_count = {}  # 清空原有数据
    for db_type in all_types:
        db_list = get_db_list(db_type)
        current_type_counts = {}
        for db_name in db_list:
            data = show_fun(db_type, db_name)
            current_type_counts[db_name] = len(data)
        db_count[db_type] = current_type_counts
    return db_count


def update_available_dbs(db_type):
    """根据数据库类型更新可用数据库列表"""
    db_list = get_db_list(db_type)  # 调用工具函数获取列表

    # 设置默认选中第一个选项
    default_value = db_list[0] if db_list else None
    db_list_1 = gr.update(choices=db_list, value=default_value)
    
    # # 更新全局字典记录数据条数
    # global db_count
    # current_type_counts = {}
    # for db_name in db_list:
    #     data = show_fun(db_type, db_name)
    #     current_type_counts[db_name] = len(data)
    # db_count[db_type] = current_type_counts  # 按类型存储各数据库的条目数
    
    return db_list_1


def handle_create_kb(db_type, kb_name, file_obj):
    """处理新建知识库逻辑"""
    if not kb_name:
        return "知识库名称不能为空"
    if not file_obj:
        return "请先上传文件"
    try:
        # 修改：确保传递的参数与后端一致
        create_vector_db(db_type.lower(), kb_name, file_obj.name, persist_dir='./db_data')
        gr.Info(f"成功创建{kb_name}知识库")
    except Exception as e:
        gr.Info(f"创建失败: {str(e)}")


def handle_delete_kb(db_type, kb_name):
    """处理删除知识库逻辑"""
    if not kb_name:
        return "请选择要删除的知识库"
    try:
        # 调用后端的 delete_db 方法
        result = delete_db(db_type.lower(), kb_name)
        gr.Info(result)
    except Exception as e:
        gr.Info(f"删除失败: {str(e)}")


def show_fun(db_type, db_name):
    """展示选中数据库信息"""
    if db_type and db_name:
        return get_all_data(db_type, db_name)
    return "未选择数据库"


if __name__ == "__main__":
    with gr.Blocks() as blocks:

        with gr.Tab("📚 知识库管理"):
            with gr.Row():
                with gr.Column(scale=1):
                    with gr.Column(elem_classes="dashboard-panel"):
                        gr.Markdown("### 文件导入解析")
                        file_upload = gr.File(
                            label="上传文档",
                            file_types=[".pdf", ".txt", ".docx", ".jpg", ".png", ".mp3"],
                            elem_classes="gr-file"
                        )
                        gr.Markdown("### 新建知识库")
                        new_knowledge_base = gr.Textbox(
                            label="请给新建的知识库【命名】后按【回车】",
                            placeholder="输入需要新建的知识库名称...",
                            visible=False
                        )
                        create_kb_btn = gr.Button("新建", elem_classes="custom-button")
                        new_kb_name_input = gr.Textbox(
                            label="输入要删除的知识库名称",
                            placeholder="在此输入要删除的知识库名称",
                            visible=False  # 修改可见性为False
                        )
                        delete_kb_btn = gr.Button("删除选定知识库", elem_classes="custom-button")

                with gr.Column(scale=1):
                    with gr.Column(elem_classes="dashboard-panel"):
                        gr.Markdown("### 向量数据库类型选择")
                        vector_db_type = gr.Radio(
                            choices=["faiss", "chroma"],
                            label="向量数据库类型",
                            value="faiss"
                        )
                        gr.Markdown("### 可用数据库名选择")
                        available_db_list = gr.Dropdown(
                            choices=[],
                            label="可用数据库名",
                            container=False
                        )
                        db_info_textbox = gr.Textbox(
                            label="数据库信息显示区",
                            interactive=False
                        )

        create_kb_btn.click(
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=new_knowledge_base,
            queue=False
        ).then(  # 新增隐藏按钮的步骤
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=create_kb_btn,
            queue=False
        )

        # 在处理完成后重新显示按钮
        new_knowledge_base.submit(
            fn=handle_create_kb,
            inputs=[vector_db_type, new_knowledge_base, file_upload],
        ).then(
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=new_knowledge_base,
            queue=False
        ).then(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        ).then(  # 新增显示按钮的步骤
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=create_kb_btn,
            queue=False
        )

        delete_kb_btn.click(
            # 显示输入框并隐藏按钮
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=new_kb_name_input,
            queue=False
        ).then(
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=delete_kb_btn,
            queue=False
        )

        # 新增new_kb_name_input的提交事件链
        new_kb_name_input.submit(
            fn=handle_delete_kb,
            inputs=[vector_db_type, new_kb_name_input],
        ).then(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        ).then(
            # 隐藏输入框并重新显示按钮
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=new_kb_name_input,
            queue=False
        ).then(
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=delete_kb_btn,
            queue=False
        )

        vector_db_type.change(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        )

        available_db_list.change(
            fn=show_fun,
            inputs=[vector_db_type,available_db_list],
            outputs=db_info_textbox
        )
    blocks.launch()
