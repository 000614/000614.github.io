import os
import chromadb
from langchain_chroma import Chroma
from langchain_community.vectorstores import FAISS
import shutil
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.document_loaders import PDFMinerLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

from langchain.tools.retriever import create_retriever_tool
import jieba
from rank_bm25 import BM25Okapi
from try_api_bd_model import try_api_bd_model

print("开始给向量数据库部分检查apikey")
try_api_bd_model("gpt-3.5-turbo")
# OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
# OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")

embedding_function = OpenAIEmbeddings()


def create_vector_db(db_type, collection_name, pdf_path, persist_dir = './db_data'):
    """创建向量数据库实例"""

    loader = PDFMinerLoader(pdf_path)
    loaded_docs = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=40)
    splits = text_splitter.split_documents(loaded_docs)

    if db_type == 'chroma':
        db = Chroma(collection_name=collection_name, embedding_function=embedding_function, persist_directory=persist_dir)
        db.add_documents(splits)
    elif db_type == 'faiss':
        db = FAISS.from_documents(splits, embedding_function)
        db.save_local(persist_dir+"/"+collection_name)
    else:
        raise ValueError("不支持的数据库类型")



def calculate_mrr(query, db_type, db_name, persist_dir = './db_data', m=60, k=10):

    if db_type == 'chroma':
        vector_db = Chroma(db_name, embedding_function, persist_dir)
        vector_res = vector_db.similarity_search(query, k=k)
    elif db_type == 'faiss':
        vector_db = FAISS.load_local(
            folder_path=persist_dir+"/"+db_name,
            embeddings=OpenAIEmbeddings(),
            allow_dangerous_deserialization=True  # 关闭警告
        )
        vector_res = vector_db.similarity_search(query, k=k)
    else:
        raise ValueError("Unsupported DB type")

    texts_list = [doc.page_content for doc in vector_res]
    tokenized_texts = [list(jieba.cut(text)) for text in texts_list]
    vectorizer = BM25Okapi(tokenized_texts)
    bm25_res = vectorizer.get_top_n(list(jieba.cut(query)), vector_res, n=k)

    doc_scores = {}
    for rank, doc in enumerate(vector_res):
        doc_scores[doc.page_content] = doc_scores.get(doc.page_content, 0) + 1/(m + rank)
    for rank, doc in enumerate(bm25_res):
        doc_scores[doc.page_content] = doc_scores.get(doc.page_content, 0) + 1/(m + rank)

    return sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)[:k]


def delete_db(db_type, db_name, persist_dir='./db_data'):
    """根据数据库类型和集合名删除数据库"""
    try:
        if db_type == 'chroma':
            chroma_db = Chroma(persist_directory=persist_dir, embedding_function=embedding_function)
            chromadb_client = chroma_db._client
            print(chromadb_client.list_collections())
            chromadb_client.delete_collection(name=db_name)
            print(chromadb_client.list_collections())
        elif db_type == 'faiss':
            db_folder = os.path.join(persist_dir, db_name)  # 定位到具体的db_name文件夹
            if os.path.exists(db_folder):
                shutil.rmtree(db_folder)  # 仅删除db_name文件夹
            else:
                raise FileNotFoundError(f"FAISS 数据库路径 {db_folder} 不存在")
        else:
            raise ValueError("不支持的数据库类型")
        return f"成功删除 {db_name} 数据库"
    except Exception as e:
        return f"删除失败: {str(e)}"


def get_db_list(db_type):
    if db_type == 'chroma':
        chroma_db = Chroma(persist_directory='./db_data')
        chromadb = chroma_db._client
        collections = chromadb.list_collections()
        return collections
    elif db_type == "faiss":
        faiss_dir = './db_data'
        faiss_folders = []
        for root, dirs, files in os.walk(faiss_dir):
            if any(f.endswith('.faiss') for f in files):
                faiss_folders.append(os.path.basename(root))
        return faiss_folders
    else:
        print("不支持的数据库类型")


def get_all_data(db_type, db_name, persist_dir='./db_data'):
    """根据数据库类型和名称返回所有文本内容，每条换行"""
    if db_type == 'chroma':
        chroma_db = Chroma(persist_directory=persist_dir, collection_name=db_name, embedding_function=embedding_function)
        results = chroma_db.similarity_search("1", k=1000)
        all_texts = [doc.page_content for doc in results]
    elif db_type == 'faiss':
        faiss_db = FAISS.load_local(
            folder_path=os.path.join(persist_dir, db_name),
            embeddings=OpenAIEmbeddings(),
            allow_dangerous_deserialization=True
        )
        results = faiss_db.similarity_search("1", k=1000)
        all_texts = [doc.page_content for doc in results]
    else:
        raise ValueError("不支持的数据库类型")
    return all_texts


if __name__ == "__main__":
    pass
    query = "默认查询"
    # db_type = "chroma"
    db_type = "faiss"
    collection_name = "testfaiss"
    PDF_PATH = r'C:\Users\ding\Desktop\gr_test\pdf\text_pdf.pdf'
    # db_name = "my_collection"
    db_name = "ffffffffff"
    # 创建数据库实例
    # db = create_vector_db(db_type, collection_name, PDF_PATH)
    # print(get_db_list(db_type))

    # delete_db(db_type, db_name, persist_dir='./db_data')

    # print(get_db_list(db_type))
    print(get_all_data(db_type, db_name))
    # results = calculate_mrr(query, db_type, db_name)
    # print(f"Top {len(results)} 结果:", [r[0] for r in results])
    #
