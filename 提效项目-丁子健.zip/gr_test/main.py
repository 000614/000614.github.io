import os

import gradio as gr
from KB_LOOK import update_tool_both, update_db_both
from agent_team import Team_Actuator
from try_re_join_in import go_to_smith, register_hotkey
from KB_Up_Loading import handle_create_kb, update_available_dbs, handle_delete_kb, show_fun
from agent_one import send_message, refresh_db_list, update_db_name, update_db_type
import re

from css import css_data
from js import js_data

# 添加侧边栏控制函数
def toggle_sidebar_visibility(visible):
    return gr.update(visible=visible)


os.environ['LANGCHAIN_TRACING_V2']="true"
os.environ['LANGCHAIN_ENDPOINT']="https://api.smith.langchain.com"
# os.environ['LANGCHAIN_API_KEY']="你的key"
os.environ['LANGCHAIN_PROJECT']="langsmith_learn2"



with gr.Blocks(
    js=js_data,
    css=css_data,
    title="智能对话平台 | AI Assistant Platform",
    theme=gr.themes.Soft(
        primary_hue="green",
        secondary_hue="emerald",
        neutral_hue="slate",
        spacing_size="md",
        radius_size="lg",
        font=[gr.themes.GoogleFont("SF Pro Display"), "ui-sans-serif", "system-ui", "sans-serif"]
    )
) as demo:
    gr.HTML('''
    <div style="text-align: center; margin: 0 auto; padding: 0.5rem 0; background: linear-gradient(90deg, #22c55e, #10b981); box-shadow: 0 2px 10px rgba(34, 197, 94, 0.2);">
        <h1 style="font-size: 1.75rem; font-weight: 600; color: white; margin: 0;">提效系统 | Efficiency Boost System</h1>
        <div class="subtitle-container" style="height: 30px; position: relative; overflow: hidden;">
            <p class="dynamic-subtitle" style="animation-delay: 0s;">智能协作 · 知识管理 · 高效决策</p>
            <p class="dynamic-subtitle" style="animation-delay: 8s;">赋能团队 · 提升效率 · 简化工作流</p>
            <p class="dynamic-subtitle" style="animation-delay: 16s;">数据可视 · 智能分析 · 辅助决策</p>
        </div>
    </div>
    ''')
    with gr.Tabs(elem_classes="tab-nav"):

        with gr.Tab("💬 智能体", id="agent-workspace"):
            # 添加装饰性元素 - 功能卡片介绍部分
            gr.HTML('''
            <div style="margin: 1rem 0 2rem 0; padding: 0 1rem;">
                <div class="feature-cards" style="display: flex; gap: 1.5rem; flex-wrap: wrap; justify-content: center;">
                    <div class="feature-card" style="flex: 1; min-width: 250px; background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); position: relative; overflow: hidden;">
                        <div style="position: absolute; top: 0; right: 0; width: 80px; height: 80px; background: radial-gradient(circle at top right, rgba(34, 197, 94, 0.2), transparent 70%);"></div>
                        <h3 style="margin-top: 0; color: #15803d; font-size: 1.2rem; font-weight: 600; border-bottom: 2px solid rgba(34, 197, 94, 0.3); padding-bottom: 0.5rem; margin-bottom: 1rem;">单智能体交互</h3>
                        <p style="color: #166534; margin-bottom: 0.5rem; line-height: 1.5;">强大的AI单体智能，可以解答问题、分析数据、提供见解。</p>
                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">提问解答</span>
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">知识检索</span>
                        </div>
                    </div>
                    <div class="feature-card" style="flex: 1; min-width: 250px; background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); position: relative; overflow: hidden;">
                        <div style="position: absolute; top: 0; right: 0; width: 80px; height: 80px; background: radial-gradient(circle at top right, rgba(34, 197, 94, 0.2), transparent 70%);"></div>
                        <h3 style="margin-top: 0; color: #15803d; font-size: 1.2rem; font-weight: 600; border-bottom: 2px solid rgba(34, 197, 94, 0.3); padding-bottom: 0.5rem; margin-bottom: 1rem;">团队智能协作</h3>
                        <p style="color: #166534; margin-bottom: 0.5rem; line-height: 1.5;">多智能体协同工作，共同解决复杂问题，发挥集体智慧。</p>
                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">集体智慧</span>
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">智能协作</span>
                        </div>
                    </div>
                    <div class="feature-card" style="flex: 1; min-width: 250px; background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); position: relative; overflow: hidden;">
                        <div style="position: absolute; top: 0; right: 0; width: 80px; height: 80px; background: radial-gradient(circle at top right, rgba(34, 197, 94, 0.2), transparent 70%);"></div>
                        <h3 style="margin-top: 0; color: #15803d; font-size: 1.2rem; font-weight: 600; border-bottom: 2px solid rgba(34, 197, 94, 0.3); padding-bottom: 0.5rem; margin-bottom: 1rem;">工具增强能力</h3>
                        <p style="color: #166534; margin-bottom: 0.5rem; line-height: 1.5;">智能体可调用多种工具，扩展能力边界，提供更精准服务。</p>
                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">能力扩展</span>
                            <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">工具集成</span>
                        </div>
                    </div>
                </div>
                <div style="text-align: center; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px dashed rgba(22, 101, 52, 0.2);">
                    <p style="color: #166534; font-size: 0.9rem; max-width: 800px; margin: 0 auto;">提效系统集成了先进的AI技术和丰富的工具集，旨在提升工作效率、促进团队协作，为您的工作流程带来革命性的提升。</p>
                </div>
            </div>
            ''')
            with gr.Tabs():
                with gr.Tab("💬 单智能体对话", id="single-agent"):
                    with gr.Row(equal_height=True):  # 新增等高布局
                        with gr.Column(scale=3, min_width=600, elem_classes="control-card"):
                            chatbot_single = gr.Chatbot(
                                label="对话历史",
                                elem_classes="chat-container",
                                height=500,
                                type='messages'
                            )
                            with gr.Row():
                                question_input_single = gr.Textbox(
                                    label="输入问题",
                                    lines=3,
                                    placeholder="请输入您的问题...",
                                    elem_classes="gr-textbox",
                                    container=False,
                                    scale=5
                                )
                                with gr.Column(scale=1):
                                    submit_button_single = gr.Button("🚀 发送", elem_classes="custom-button")
                                    clear_btn_single = gr.Button("🧹 清空", elem_classes="custom-button")

                        # 右侧控制面板添加高度限制和容器样式
                        with gr.Column(scale=1, min_width=200, elem_classes="control-card dashboard-panel"):  # 新增样式
                            db_type_radio = gr.Radio(
                                choices=["faiss", "chroma"],
                                label="选择数据库类型",
                                value=None,
                            )

                            dataset_dropdown_single = gr.Dropdown(
                                choices=["请点击上方选择知识库类型"],
                                label="选择知识库",
                                value="请点击上方选择知识库类型"
                            )
                            dataset_dropdown_single.change(
                                fn=update_db_name,
                                inputs=[dataset_dropdown_single],
                                outputs=[]
                            )
                            tool_list_single = gr.CheckboxGroup(
                                choices=["联网搜索", "RAG向量数据库检索", "乘法计算"],
                                label="选择可用工具",
                                value=["联网搜索", "RAG向量数据库检索", "乘法计算"],
                                container=False
                            )
                            temperature = gr.Slider(0, 1, value=0.7, label="温度系数")
                            tool_name_result = gr.Textbox(label="已调用工具名称", interactive=False)
                            tool_result = gr.Textbox(label="工具调用结果", interactive=False)

                db_type_radio.change(
                    fn=update_db_type,
                    inputs=[db_type_radio],
                    outputs=[]
                ).then(
                    fn=refresh_db_list,
                    outputs=[dataset_dropdown_single]
                )
                submit_button_single.click(
                    send_message,
                    inputs=[question_input_single, chatbot_single, tool_list_single, temperature],
                    outputs=[chatbot_single, tool_result, tool_name_result]
                )

                # 团队智能体面板
                with gr.Tab("👥 团队协作智能体", id="team-agent"):
                    team_pe = Team_Actuator()
                    
                    # 先创建控制按钮
                    # with gr.Row():
                    #     with gr.Column(scale=20):
                    #         pass
                    #     with gr.Column(scale=1):
                    #         show_sidebar_btn = gr.Button("☰ 显示设置", elem_classes="custom-button")
                    #         hide_sidebar_btn = gr.Button("✕ 隐藏设置", elem_classes="custom-button", visible=False)
                    #
                    # 创建可控制的侧边栏
                    sidebar = gr.Sidebar(visible=False)
                    with sidebar:
                        with gr.Column():
                            gr.Markdown("### 创建agent配置")
                            with gr.Column():
                                cre_agent_name = gr.Textbox(label="Agent成员名字")
                                cre_agent_type = gr.Textbox(label="Agent成员描述")
                                # cre_agent_params = gr.Textbox(label="Agent成员系统提示词")
                            add_agent_btn = gr.Button("添加Agent")
                            jian_agent_btn = gr.Button("删除Agent")
                            gr.Markdown("### 已有agent如下")
                            add_agent_btn.click(fn=team_pe.add_len_agent)
                            jian_agent_btn.click(fn=team_pe.jian_len_agent)

                            @gr.render(inputs=[], triggers=[add_agent_btn.click, jian_agent_btn.click])
                            def add_agent_component():
                                for i in range(team_pe.len_agent):
                                    with gr.Column():
                                        agent_name = gr.Textbox(team_pe.agent_configs[i][0],
                                                                label=f"第{i + 1}个Agent成员", )
                                        agent_type = gr.Textbox(team_pe.agent_configs[i][1], label="Agent成员描述")
                                        # agent_params = gr.Textbox(label="Agent成员系统提示词")
                    
                    # 设置侧边栏切换按钮点击事件

                    # 主对话区布局
                    with gr.Row():
                        with gr.Column(scale=3, elem_classes="chat-container"):
                            chatbot_team = gr.Chatbot(
                                label="团队对话",
                                elem_classes="chat-container",
                                height=500,
                                type='messages'
                            )
                            with gr.Row():
                                question_input_team = gr.Textbox(
                                    label="输入问题",
                                    lines=3,
                                    placeholder="请输入需要协作解决的问题...",
                                    elem_classes="gr-textbox",
                                    container=False,
                                    scale=5
                                )
                                with gr.Column(scale=1):
                                    submit_button_team = gr.Button("🚀 发送", elem_classes="custom-button")
                                    clear_btn_team = gr.Button("🧹 清空", elem_classes="custom-button")

                        # 协作控制面板
                        with gr.Column(scale=1, min_width=200, elem_classes="control-card"):
                            gr.Markdown("### 协作设置")
                            show_sidebar_btn = gr.Button("☰ 显示设置", elem_classes="custom-button")
                            hide_sidebar_btn = gr.Button("✕ 隐藏设置", elem_classes="custom-button", visible=False)

                            gr.Markdown("### 中央管理器（成员管理者）：")
                            # agent_manager = gr.Textbox(label="中央管理器")
                            max_runs = gr.Textbox(label="最大迭代轮数（以总结次数记作轮数，可作为安全轮数上限）")
                            path_max = gr.Textbox(label="问题解决终点（指问题解决到什么程度就由模型判断结束）")

                    show_sidebar_btn.click(
                        fn=lambda: (gr.update(visible=True), gr.update(visible=False), gr.update(visible=True)),
                        outputs=[sidebar, show_sidebar_btn, hide_sidebar_btn]
                    )

                    hide_sidebar_btn.click(
                        fn=lambda: (gr.update(visible=False), gr.update(visible=True), gr.update(visible=False)),
                        outputs=[sidebar, show_sidebar_btn, hide_sidebar_btn]
                    )

                    add_agent_btn.click(
                        fn=team_pe.add_btn,
                        inputs=[cre_agent_name, cre_agent_type],
                    )
                    jian_agent_btn.click(
                        fn=team_pe.jian_btn,
                    )

                    submit_button_team.click(
                        fn=team_pe.submit_question,
                        inputs=[chatbot_team, cre_agent_name, cre_agent_type, question_input_team, max_runs],
                        outputs=[chatbot_team]
                    )
                    clear_btn_team.click(
                        fn=team_pe.clear_chat,
                        outputs=[chatbot_team]
                    )

        with gr.Tab("📚 知识库中心", id="kb-management"):
            # 添加知识库中心的装饰性元素
            gr.HTML('''
            <div style="margin: 1rem 0 2rem 0; padding: 0 1rem;">
                <div style="background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); margin-bottom: 2rem;">
                    <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                        <div style="flex: 1; min-width: 300px;">
                            <h3 style="margin-top: 0; color: #15803d; font-size: 1.3rem; font-weight: 600; margin-bottom: 1rem;">知识库管理中心</h3>
                            <p style="color: #166534; margin-bottom: 1rem; line-height: 1.6;">在这里，您可以创建、管理和优化您的知识库，支持多种文件格式的导入和解析，为AI提供丰富的知识背景。</p>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 1rem;">
                                <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: flex; align-items: center;"><span style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; margin-right: 5px;"></span>文档导入</span>
                                <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: flex; align-items: center;"><span style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; margin-right: 5px;"></span>知识检索</span>
                                <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: flex; align-items: center;"><span style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; margin-right: 5px;"></span>智能索引</span>
                                <span style="background: rgba(34, 197, 94, 0.1); color: #15803d; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; display: flex; align-items: center;"><span style="width: 8px; height: 8px; background: #22c55e; border-radius: 50%; margin-right: 5px;"></span>内容解析</span>
                            </div>
                        </div>
                        <div style="flex: 0 0 auto; max-width: 180px; position: relative;">
                            <div style="position: relative; width: 150px; height: 150px; border-radius: 50%; background: rgba(34, 197, 94, 0.1); display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                                <div style="position: absolute; width: 120px; height: 120px; border-radius: 50%; border: 3px dashed rgba(34, 197, 94, 0.3); animation: rotate 20s linear infinite;"></div>
                                <div style="font-size: 2.5rem; color: #15803d; text-align: center;">📚</div>
                            </div>
                            <style>
                                @keyframes rotate {
                                    from { transform: rotate(0deg); }
                                    to { transform: rotate(360deg); }
                                }
                            </style>
                        </div>
                    </div>
                </div>
                <div style="display: flex; justify-content: center; gap: 1rem; margin-bottom: 1rem; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px; max-width: 300px; background: white; border-radius: 8px; padding: 1rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; text-align: center;">
                        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">📄</div>
                        <div style="font-weight: 600; color: #334155; margin-bottom: 0.25rem;">文档管理</div>
                        <div style="font-size: 0.85rem; color: #64748b;">导入、分类和组织文档</div>
                    </div>
                    <div style="flex: 1; min-width: 200px; max-width: 300px; background: white; border-radius: 8px; padding: 1rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; text-align: center;">
                        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">🔍</div>
                        <div style="font-weight: 600; color: #334155; margin-bottom: 0.25rem;">向量检索</div>
                        <div style="font-size: 0.85rem; color: #64748b;">高效语义搜索和内容匹配</div>
                    </div>
                    <div style="flex: 1; min-width: 200px; max-width: 300px; background: white; border-radius: 8px; padding: 1rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; text-align: center;">
                        <div style="font-size: 1.8rem; margin-bottom: 0.5rem;">⚙️</div>
                        <div style="font-weight: 600; color: #334155; margin-bottom: 0.25rem;">库管理</div>
                        <div style="font-size: 0.85rem; color: #64748b;">创建、更新和维护知识库</div>
                    </div>
                </div>
            </div>
            ''')
            with gr.Row():
                with gr.Column(scale=1):
                    with gr.Column(elem_classes="dashboard-panel"):
                        gr.Markdown("### 文件导入解析")
                        file_upload = gr.File(
                            label="上传文档",
                            file_types=[".pdf", ".txt", ".docx", ".jpg", ".png", ".mp3"],
                            elem_classes="gr-file"
                        )
                        gr.Markdown("### 新建知识库")
                        new_knowledge_base = gr.Textbox(
                            label="请给新建的知识库【命名】后按【回车】",
                            placeholder="输入需要新建的知识库名称...",
                            visible=False
                        )
                        create_kb_btn = gr.Button("新建", elem_classes="custom-button")
                        new_kb_name_input = gr.Textbox(
                            label="输入要删除的知识库名称",
                            placeholder="在此输入要删除的知识库名称",
                            visible=False  # 修改可见性为False
                        )
                        delete_kb_btn = gr.Button("删除选定知识库", elem_classes="custom-button")

                with gr.Column(scale=1):
                    with gr.Column(elem_classes="dashboard-panel"):
                        gr.Markdown("### 向量数据库类型选择")
                        vector_db_type = gr.Radio(
                            choices=["faiss", "chroma"],
                            label="向量数据库类型",
                            value="faiss"
                        )
                        gr.Markdown("### 可用数据库名选择")
                        available_db_list = gr.Dropdown(
                            choices=[],
                            label="可用数据库名",
                            container=False
                        )
                        db_info_textbox = gr.Textbox(
                            label="数据库信息显示区",
                            interactive=False
                        )

        create_kb_btn.click(
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=new_knowledge_base,
            queue=False
        ).then(  # 新增隐藏按钮的步骤
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=create_kb_btn,
            queue=False
        )
        # 在处理完成后重新显示按钮

        new_knowledge_base.submit(
            fn=handle_create_kb,
            inputs=[vector_db_type, new_knowledge_base, file_upload],
        ).then(
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=new_knowledge_base,
            queue=False
        ).then(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        ).then(  # 新增显示按钮的步骤
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=create_kb_btn,
            queue=False
        )

        delete_kb_btn.click(
            # 显示输入框并隐藏按钮
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=new_kb_name_input,
            queue=False
        ).then(
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=delete_kb_btn,
            queue=False
        )
        # 新增new_kb_name_input的提交事件链

        new_kb_name_input.submit(
            fn=handle_delete_kb,
            inputs=[vector_db_type, new_kb_name_input],
        ).then(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        ).then(
            # 隐藏输入框并重新显示按钮
            fn=lambda: gr.update(visible=False),
            inputs=None,
            outputs=new_kb_name_input,
            queue=False
        ).then(
            fn=lambda: gr.update(visible=True),
            inputs=None,
            outputs=delete_kb_btn,
            queue=False
        )

        vector_db_type.change(
            fn=update_available_dbs,
            inputs=[vector_db_type],
            outputs=available_db_list
        )
        available_db_list.change(
            fn=show_fun,
            inputs=[vector_db_type, available_db_list],
            outputs=db_info_textbox
        )
        with gr.Tab("⚙️ 系统设置", id="config-center"):
            # 添加系统设置页的装饰性元素
            gr.HTML('''
            <div style="margin: 1rem 0 2rem 0; padding: 0 1rem;">
                <div style="background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); margin-bottom: 2rem;">
                    <h3 style="margin-top: 0; color: #15803d; font-size: 1.3rem; font-weight: 600; margin-bottom: 1rem; display: flex; align-items: center;">
                        <span style="margin-right: 0.5rem;">⚙️</span> 系统控制与配置中心
                    </h3>
                    <p style="color: #166534; line-height: 1.6;">在这里您可以自定义系统行为、配置外部集成以及管理全局设置。所有更改将实时生效，无需重启系统。</p>
                </div>
                
                <div style="display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;">
                    <div style="flex: 1; min-width: 250px; background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; position: relative;">
                        <div style="position: absolute; top: -10px; right: -10px; width: 24px; height: 24px; background: #22c55e; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">✓</div>
                        <h4 style="margin-top: 0; margin-bottom: 1rem; color: #334155; font-size: 1.1rem; font-weight: 600;">外部集成</h4>
                        <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 1.5rem;">配置与外部系统的连接和数据交换，包括LangSmith监控和其他工具。</p>
                    </div>
                    
                    <div style="flex: 1; min-width: 250px; background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e5e7eb; position: relative;">
                        <div style="position: absolute; top: -10px; right: -10px; width: 24px; height: 24px; background: #22c55e; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 12px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">✓</div>
                        <h4 style="margin-top: 0; margin-bottom: 1rem; color: #334155; font-size: 1.1rem; font-weight: 600;">自动化设置</h4>
                        <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 1.5rem;">配置系统自动行为，包括热键绑定、自动化任务和辅助功能设置。</p>
                    </div>
                </div>
            </div>
            
            <!-- 浮动指示器 -->
            <div id="floating-indicator" style="position: fixed; bottom: 20px; right: 20px; background: rgba(34, 197, 94, 0.9); color: white; padding: 0.5rem 1rem; border-radius: 20px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); font-size: 0.9rem; display: flex; align-items: center; gap: 0.5rem; z-index: 1000; opacity: 0; transform: translateY(20px); transition: all 0.3s ease;">
                <span style="width: 8px; height: 8px; background: white; border-radius: 50%; display: inline-block;"></span>
                <span>系统运行正常</span>
            </div>
            
            <script>
                setTimeout(function() {
                    const indicator = document.getElementById('floating-indicator');
                    if (indicator) {
                        indicator.style.opacity = '1';
                        indicator.style.transform = 'translateY(0)';
                        
                        setInterval(function() {
                            indicator.style.opacity = '0';
                            indicator.style.transform = 'translateY(20px)';
                            
                            setTimeout(function() {
                                indicator.style.opacity = '1';
                                indicator.style.transform = 'translateY(0)';
                            }, 3000);
                        }, 10000);
                    }
                }, 2000);
            </script>
            ''')
            with gr.Row():
                with gr.Column(scale=1):
                    with gr.Column(elem_classes="dashboard-panel"):

                        tencent_meeting_reconnect = gr.Checkbox(label="启用腾讯会议重登功能(全局热键已绑定至\"↑\"键)", value=False)

                        tencent_meeting_reconnect.change(
                            fn=register_hotkey,
                            inputs=[tencent_meeting_reconnect],
                            show_progress=False
                        )

                        # 新增按钮组件
                        go_to_smith_btn = gr.Button("跳转到Smith系统查看监控", elem_classes="custom-button")
                        go_to_smith_btn.click(go_to_smith)

        # 数据可视化
        with gr.Tab("📊 数据分析中心", id="data-visualization") as tab:
            # 添加数据分析中心的装饰性元素
            gr.HTML('''
            <div style="margin: 1rem 0 2rem 0; padding: 0 1rem;">
                <div style="background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); margin-bottom: 2rem;">
                    <h3 style="margin-top: 0; color: #15803d; font-size: 1.3rem; font-weight: 600; margin-bottom: 0.5rem; display: flex; align-items: center;">
                        <span style="margin-right: 0.5rem;">📊</span> 数据可视化与分析平台
                    </h3>
                    <p style="color: #166534; margin-bottom: 1rem; line-height: 1.6;">实时监控系统性能，掌握数据变化趋势，辅助决策和系统优化。</p>
                    
                    <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1.5rem;">
                        <div style="flex: 1; min-width: 200px; padding: 1rem; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <span style="width: 10px; height: 10px; background: #22c55e; border-radius: 50%;"></span>
                                <span style="font-weight: 600; color: #334155;">工具调用分析</span>
                            </div>
                            <p style="font-size: 0.85rem; color: #64748b; margin: 0;">监控各工具使用频率和性能表现</p>
                        </div>
                        <div style="flex: 1; min-width: 200px; padding: 1rem; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <span style="width: 10px; height: 10px; background: #22c55e; border-radius: 50%;"></span>
                                <span style="font-weight: 600; color: #334155;">数据库容量监测</span>
                            </div>
                            <p style="font-size: 0.85rem; color: #64748b; margin: 0;">了解数据存储情况和空间分配</p>
                        </div>
                        <div style="flex: 1; min-width: 200px; padding: 1rem; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <span style="width: 10px; height: 10px; background: #22c55e; border-radius: 50%;"></span>
                                <span style="font-weight: 600; color: #334155;">性能指标追踪</span>
                            </div>
                            <p style="font-size: 0.85rem; color: #64748b; margin: 0;">跟踪关键性能指标变化趋势</p>
                        </div>
                    </div>
                </div>
                <!-- 数据探索引导 -->
                <div style="text-align: center; margin-bottom: 1.5rem; padding: 1rem; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); border: 1px solid #e5e7eb;">
                    <p style="color: #334155; font-weight: 500; margin: 0;">点击下方的"刷新"按钮获取最新的分析数据，帮助您做出更明智的决策。</p>
                </div>
            </div>
            ''')
            gr.Markdown("### 工具调用统计")
            with gr.Row():
                tool_plot = gr.Plot(label="工具调用柱状图")
                tool_pie_plot = gr.Plot(label="工具调用分布饼图")
            tool_refresh_btn = gr.Button("🔄 刷新工具数据", elem_classes="custom-button")

            gr.Markdown("### 数据库调用统计")
            with gr.Row():
                db_plot = gr.Plot(label="数据库容量柱状图")
                db_pie_plot = gr.Plot(label="数据库容量分布饼图")
            db_refresh_btn = gr.Button("🔄 刷新数据库数据", elem_classes="custom-button")
            tool_refresh_btn.click(
                fn=update_tool_both,
                outputs=[tool_plot, tool_pie_plot]
            )

            db_refresh_btn.click(
                fn=update_db_both,
                outputs=[db_plot, db_pie_plot]
            )

        with gr.Tab("📝 笔记中心", id="local-notes"):
            # 添加笔记中心装饰性元素
            gr.HTML('''
            <div style="margin: 1rem 0 2rem 0; padding: 0 1rem;">
                <div style="background: linear-gradient(135deg, #f0fdf4, #dcfce7); border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border: 1px solid rgba(22, 101, 52, 0.1); margin-bottom: 2rem; text-align: center;">
                    <h3 style="margin-top: 0; color: #15803d; font-size: 1.3rem; font-weight: 600; margin-bottom: 0.5rem;">个人笔记与知识管理</h3>
                    <p style="color: #166534; margin-bottom: 1rem; line-height: 1.6; max-width: 700px; margin-left: auto; margin-right: auto;">将您的灵感、笔记和重要信息集中管理，随时查阅和编辑，提高信息组织和访问效率。</p>
                    <div style="display: inline-block; margin-top: 1rem; padding: 0.5rem 1.5rem; background: rgba(34, 197, 94, 0.1); border-radius: 20px; color: #15803d; font-weight: 500;">
                        本地笔记同步已启用
                    </div>
                </div>
            </div>
            ''')
            with gr.Row():
                with gr.Column():
                    with open("C:/Users/ding/Desktop/local_note/ai-note-win.html", "r", encoding="utf-8") as f:
                        html_content = f.read()

                    html_content = re.sub(r'(width\s*:\s*\S+;?)', '', html_content)

                    local_note_viewer = gr.HTML(
                        value=html_content,
                        label="本地笔记预览"
                    )

# 自定义页脚，移除Gradio品牌标识
footer_html = """
<div style="text-align: center; margin-top: 2rem; padding: 1rem; border-top: 1px solid #bbf7d0; background: linear-gradient(180deg, rgba(240, 253, 244, 0), rgba(240, 253, 244, 0.7));">
    <p style="color: #15803d; font-size: 0.875rem;">© 2024 提效系统 | Efficiency Boost System. All rights reserved.</p>
</div>
"""
gr.HTML(footer_html)

# 现代化的启动选项
demo.launch(
    share=True,             # 创建公共链接
    inbrowser=True,         # 自动在浏览器中打开
    show_api=False,         # 隐藏API文档
    # favicon_path="https://www.svgrepo.com/show/306500/openai.svg",  # 设置网页图标
    show_error=False        # 隐藏错误
)