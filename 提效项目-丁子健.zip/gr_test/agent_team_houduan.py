from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.prompts import PromptTemplate
from try_api_bd_model import try_api_bd_model


class Team_Manager:
    agents = {}

    def configure_agent_description(self, agent_id: str, description: str, tools: list = None, temperature: float = None) -> bool:
        #配置Agent描述模板
        if agent_id not in self.agents:
            return False

        agent_info = self.agents[agent_id]
        current_executor = agent_info["executor"]
        model = agent_info["model"]
        current_tools = current_executor.tools

        # 处理新传入的tools参数
        if tools is not None:
            current_tools = tools

        # 处理新传入的temperature参数
        if temperature is not None:
            model = model.with_config(configurable={"llm_temperature": temperature})
            agent_info["model"] = model  # 更新存储的模型实例

        # 构建新Prompt模板
        new_prompt = PromptTemplate(
            input_variables=["input", "tools_names", "agent_scratchpad"],
            template=(
                f"{description}\n"
                "问题：{input}\n"
                "可用工具：{tools_names}\n"
                "{agent_scratchpad}"
            )
        )

        # 使用更新后的参数重新生成Agent
        new_agent = create_tool_calling_agent(model, current_tools, new_prompt)
        new_executor = AgentExecutor(agent=new_agent, tools=current_tools)
        agent_info["executor"] = new_executor
        return True


    def create_and_configure_agents(self, agent_configs):
        #创建并配置多个Agent
        for agent_name, description, prompt in agent_configs:
            tools = []
            temperature = 0.7

            """创建并注册Agent"""
            model = try_api_bd_model("gpt-3.5-turbo")
            model = model.with_config(configurable={"llm_temperature": temperature})

            prompt = PromptTemplate(
                input_variables=["input", "tools_names", "agent_scratchpad"],
                template="""你是一个智能助手，擅长借助工具回答用户的问题。当你需要获取额外信息时，可调用提供的工具.
                    问题：{input}
                    可用工具：{tools_names}
                    {agent_scratchpad}"""
            )
            agent = create_tool_calling_agent(model, tools, prompt)
            executor = AgentExecutor(agent=agent, tools=tools)

            self.agents[agent_name] = {
                "executor": executor,
                "model": model
            }
            self.configure_agent_description(agent_name, description)

    def central_manager(self, agent_configs, user_question, max_try):
        max_try = int(max_try)
        # 中央管理器，收集每个agent的回答并监控总结轮数
        self.create_and_configure_agents(agent_configs)
        discussion = []
        current_input = user_question

        for round_num in range(max_try):
            round_responses = {}
            for agent_name, _, _ in agent_configs:

                agent_info = self.agents.get(agent_name)
                if not agent_info:
                    return None

                executor = agent_info["executor"]
                tools_names = [tool.name for tool in executor.tools]
                invoke_args = {
                    "input": current_input,
                    "tools_names": ", ".join(tools_names)
                }
                resp = executor.invoke(invoke_args)
                response = resp["output"]

                round_responses[agent_name] = response

            discussion.append(round_responses)

            # 中央管理器的总结
            summary = f"第{round_num + 1}轮总结：\n"
            for agent_name, resp in round_responses.items():
                summary += f"  {agent_name}: {resp}\n"

            # 将本轮讨论内容拼接为下一轮输入
            current_input = f"前序讨论：\n" + "\n".join([
                f"Agent {agent_name}: {resp}" for agent_name, resp in round_responses.items()
            ]) + "。请根据前序讨论，继续回答"

            yield round_responses, summary




    def print_results(self, agent_responses, summary):
        """打印本轮结果"""
        print("本轮各Agent输出：", agent_responses)
        print("中央管理器总结：", summary)




#
#
# if __name__ == "__main__":
#     agent_configs = get_agent_configs()
#     user_question = get_user_question()
#     max_try = get_max_try()
#
#     for agent_responses, summary in central_manager(agent_configs, user_question, max_try):
#         print_results(agent_responses, summary)