js_data = '''


function() {
    // 创建打字机效果
    const createTypewriterEffect = (element, text, speed = 100, delay = 0) => {
        if (!element) return;
        
        element.textContent = '';
        element.style.opacity = '1';
        
        setTimeout(() => {
            let i = 0;
            const typeInterval = setInterval(() => {
                if (i < text.length) {
                    element.textContent += text.charAt(i);
                    i++;
                } else {
                    clearInterval(typeInterval);
                }
            }, speed);
        }, delay);
    };
    
    // 添加页面入场动画
    const addEntranceAnimation = () => {
        // 容器淡入
        const container = document.querySelector('.gradio-container');
        if (container) {
            container.style.opacity = '0';
            container.style.transform = 'translateY(20px)';
            container.style.transition = 'opacity 1.2s ease-out, transform 1.2s ease-out';
            
            setTimeout(() => {
                container.style.opacity = '1';
                container.style.transform = 'translateY(0)';
            }, 300);
        }
        
        // 标签栏入场动画
        const tabs = document.querySelectorAll('.tab-nav button');
        tabs.forEach((tab, index) => {
            tab.style.opacity = '0';
            tab.style.transform = 'translateY(-15px)';
            tab.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            
            setTimeout(() => {
                tab.style.opacity = '1';
                tab.style.transform = 'translateY(0)';
            }, 500 + index * 120);
        });
        
        // 卡片浮现动画
        const cards = document.querySelectorAll('.control-card, .dashboard-panel, .feature-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'scale(0.95)';
            card.style.transition = 'all 1s ease';
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'scale(1)';
            }, 800 + index * 150);
        });
        
        // 添加粒子特效背景
        const createParticleBackground = () => {
            const style = document.createElement('style');
            style.textContent = `
                .particle {
                    position: fixed;
                    border-radius: 50%;
                    background-color: rgba(34, 197, 94, 0.2);
                    pointer-events: none;
                    z-index: -1;
                }
            `;
            document.head.appendChild(style);
            
            for (let i = 0; i < 30; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 20 + 5;
                const xPos = Math.random() * window.innerWidth;
                const yPos = Math.random() * window.innerHeight;
                const duration = Math.random() * 40 + 30;
                const delay = Math.random() * 10;
                
                particle.style.width = `\${size}px`;
                particle.style.height = `\${size}px`;
                particle.style.left = `\${xPos}px`;
                particle.style.top = `\${yPos}px`;
                particle.style.opacity = (Math.random() * 0.3 + 0.1).toString();
                
                particle.style.animation = `float \${duration}s ease-in-out \${delay}s infinite`;
                
                document.body.appendChild(particle);
            }
            
            const keyframes = `
                @keyframes float {
                    0%, 100% { transform: translate(0, 0); }
                    25% { transform: translate(\${Math.random() * 50 - 25}px, \${Math.random() * 50 - 25}px); }
                    50% { transform: translate(\${Math.random() * 50 - 25}px, \${Math.random() * 50 - 25}px); }
                    75% { transform: translate(\${Math.random() * 50 - 25}px, \${Math.random() * 50 - 25}px); }
                }
            `;
            
            const styleSheet = document.createElement('style');
            styleSheet.type = 'text/css';
            styleSheet.innerText = keyframes;
            document.head.appendChild(styleSheet);
        };
        
        setTimeout(createParticleBackground, 2000);
        
        // 添加3D悬停效果
        const addTiltEffect = () => {
            const cards = document.querySelectorAll('.feature-card, .control-card');
            cards.forEach(card => {
                card.addEventListener('mousemove', function(e) {
                    const rect = this.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    
                    const xPercent = x / rect.width;
                    const yPercent = y / rect.height;
                    
                    const xTilt = (xPercent - 0.5) * 10;
                    const yTilt = (yPercent - 0.5) * -10;
                    
                    this.style.transform = `perspective(1000px) rotateX(\${yTilt}deg) rotateY(\${xTilt}deg) scale3d(1.02, 1.02, 1.02)`;
                    this.style.transition = 'transform 0.1s ease';
                    
                    // 添加光影效果
                    const glare = this.querySelector('.glare') || document.createElement('div');
                    if (!this.querySelector('.glare')) {
                        glare.classList.add('glare');
                        glare.style.position = 'absolute';
                        glare.style.top = '0';
                        glare.style.left = '0';
                        glare.style.width = '100%';
                        glare.style.height = '100%';
                        glare.style.borderRadius = 'inherit';
                        glare.style.pointerEvents = 'none';
                        this.appendChild(glare);
                    }
                    
                    const glareX = xPercent * 100;
                    const glareY = yPercent * 100;
                    glare.style.background = `radial-gradient(circle at \${glareX}% \${glareY}%, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 50%)`;
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
                    this.style.transition = 'transform 0.5s ease';
                    
                    const glare = this.querySelector('.glare');
                    if (glare) {
                        glare.style.background = 'none';
                    }
                });
            });
        };
        
        setTimeout(addTiltEffect, 2500);
        
        // 按钮脉冲效果
        const addPulseToButtons = () => {
            const buttons = document.querySelectorAll('.custom-button');
            buttons.forEach(button => {
                button.addEventListener('mouseover', function() {
                    this.style.animation = 'pulse 1.5s infinite';
                });
                button.addEventListener('mouseout', function() {
                    this.style.animation = 'none';
                });
            });
        };
        
        // 添加脉冲动画CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pulse {
                0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4); }
                70% { box-shadow: 0 0 0 10px rgba(34, 197, 94, 0); }
                100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
            }
            
            @keyframes floatUp {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-10px); }
            }
            
            @keyframes shimmer {
                0% { background-position: -100% 0; }
                100% { background-position: 200% 0; }
            }
            
            .float-animation {
                animation: floatUp 6s ease-in-out infinite;
            }
            
            .shimmer-effect {
                background: linear-gradient(90deg, 
                    rgba(255,255,255,0) 0%, 
                    rgba(255,255,255,0.2) 50%, 
                    rgba(255,255,255,0) 100%);
                background-size: 200% 100%;
                animation: shimmer 3s infinite;
            }
        `;
        document.head.appendChild(style);
        
        setTimeout(addPulseToButtons, 1500);
    };
    
    // 为组件添加滚动入场动画
    const addScrollAnimations = () => {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        // 添加滚动动画CSS
        const style = document.createElement('style');
        style.textContent = `
            .animate-on-scroll {
                opacity: 0;
                transform: translateY(30px);
                transition: opacity 1.5s ease, transform 1.5s ease;
            }
            
            .animate-in {
                opacity: 1 !important;
                transform: translateY(0) !important;
            }
        `;
        document.head.appendChild(style);
        
        // 选择需要添加动画的元素
        setTimeout(() => {
            const elementsToAnimate = document.querySelectorAll('.gr-block, .gr-form, .gr-panel, .gr-box');
            elementsToAnimate.forEach(el => {
                el.classList.add('animate-on-scroll');
                observer.observe(el);
            });
        }, 1000);
    };
    
    // 添加波纹点击效果
    const addRippleEffect = () => {
        const style = document.createElement('style');
        style.textContent = `
            .ripple {
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.4);
                transform: scale(0);
                animation: ripple 0.8s linear;
                pointer-events: none;
            }
            
            @keyframes ripple {
                to {
                    transform: scale(2.5);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
        
        document.addEventListener('click', function(e) {
            const buttons = document.querySelectorAll('button, .custom-button, .gr-button, .gr-form button');
            
            buttons.forEach(button => {
                const rect = button.getBoundingClientRect();
                
                if (
                    e.clientX >= rect.left &&
                    e.clientX <= rect.right &&
                    e.clientY >= rect.top &&
                    e.clientY <= rect.bottom
                ) {
                    const ripple = document.createElement('span');
                    ripple.classList.add('ripple');
                    button.appendChild(ripple);
                    
                    const x = e.clientX - rect.left;
                    const y = e.clientY - rect.top;
                    
                    ripple.style.left = `\${x}px`;
                    ripple.style.top = `\${y}px`;
                    
                    setTimeout(() => {
                        ripple.remove();
                    }, 800);
                }
            });
        });
    };
    
    // 添加浮动效果到特定元素
    const addFloatingEffect = () => {
        setTimeout(() => {
            const elementsToFloat = document.querySelectorAll('.gr-panel > div > h3, .gr-box > div > h3');
            elementsToFloat.forEach(el => {
                el.style.position = 'relative';
                el.classList.add('float-animation');
            });
            
            // 为按钮添加光泽效果
            const buttons = document.querySelectorAll('.custom-button');
            buttons.forEach(button => {
                button.style.position = 'relative';
                button.style.overflow = 'hidden';
                
                const shimmer = document.createElement('div');
                shimmer.classList.add('shimmer-effect');
                shimmer.style.position = 'absolute';
                shimmer.style.top = '0';
                shimmer.style.left = '0';
                shimmer.style.width = '100%';
                shimmer.style.height = '100%';
                shimmer.style.pointerEvents = 'none';
                
                button.appendChild(shimmer);
            });
        }, 2000);
    };
    
    // 初始化所有动画
    setTimeout(() => {
        addEntranceAnimation();
        addScrollAnimations();
        addRippleEffect();
        addFloatingEffect();
    }, 300);
    
    return [];
}
'''