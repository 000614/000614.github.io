import webbrowser

import pygetwindow as gw
import pyautogui
import time
import subprocess

from pynput import keyboard


def auto_join_meeting():
    # 切换到腾讯会议窗口
    try:
        # 遍历所有窗口查找包含“腾讯会议”的窗口
        window = None
        for w in gw.getAllWindows():
            if '腾讯会议' in w.title:
                window = w
                break
        if not window:
            raise IndexError("未找到腾讯会议窗口")
        # 检查窗口是否最小化并恢复
        if window.isMinimized:
            window.restore()
        # 移动窗口到屏幕左上角确保可见
        window.moveTo(0, 0)
        window.activate()
        time.sleep(0.5)
    except IndexError:
        print("未找到腾讯会议窗口，尝试启动腾讯会议...")
        subprocess.run(f'start "" "D:\\Tencent\\WeMeet\\wemeetapp.exe"', shell=True)
        
        # 将固定等待替换为循环检查（最多40秒，每0.5秒检查一次）
        max_attempts = 40
        window = None
        for _ in range(max_attempts):
            for w in gw.getAllWindows():
                if '腾讯会议' in w.title:
                    window = w
                    break
            if window:
                break
            time.sleep(0.5)
        if not window:
            print("启动后仍未找到腾讯会议窗口")
            return "启动后仍未找到腾讯会议窗口"
        
        # 恢复窗口并激活
        if window.isMinimized:
            window.restore()  # 新增恢复窗口
        window.moveTo(0, 0)
        window.activate()
        time.sleep(0.5)  # 新增激活窗口操作

    time.sleep(2)

    pyautogui.click(x=234, y=261)   # 点击第一个加入会议
    time.sleep(0.5)


    pyautogui.click(x=492, y=201)
    time.sleep(0.5)
    # 输入会议号
    pyautogui.typewrite('9765258298')  # 在输入框输入会议号
    time.sleep(0.5)
    # 点击第二个加入会议按钮
    pyautogui.click(x=599, y=989)
    time.sleep(0.5)

    # 点击确认弹窗中的加入按钮
    pyautogui.click(x=774, y=628)
    # input("移动鼠标到最终加入按钮后按回车:")
    # print("当前坐标:", pyautogui.position())
    print("已完成加入会议标准动作")
    return "已完成加入会议标准动作"

def go_to_smith():
    url = "https://smith.langchain.com/o/3574cbe3-7256-4b1c-b80b-8762f0382ba2/projects/p/f7ef979b-ec96-4a37-a1f1-ad5497be0ed8?timeModel=%7B%22duration%22%3A%227d%22%7D"
    webbrowser.open(url, new=2)
    return


def register_hotkey(enable):
    if enable:
        def on_press(key):
            if key == keyboard.Key.up:
                print("已按下热键:上箭头")
                auto_join_meeting()
        global listener
        listener = keyboard.Listener(on_press=on_press)
        listener.start()
    else:
        listener.stop()
        listener = None

if __name__ == "__main__":
    auto_join_meeting()