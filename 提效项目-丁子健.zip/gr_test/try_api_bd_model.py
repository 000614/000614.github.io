import os
from langchain_openai import ChatOpenAI
from langchain_core.runnables import ConfigurableField

all_openai_api_data = {
    # "bug_test_01": {
    #     "api_key": "000",
    #     "base_url": "000",
    # },
    # "bug_test_02": {
    #     "api_key": "000",
    #     "base_url": "000",
    # },
    # 这个GPT-API-free是从github上面发现的项目，也是用的openai协议，按每天的免费次数算的
    "GPT-API-free": {
        "api_key": os.getenv("GPT-API-free_API_KEY"),
        "base_url": os.getenv("GPT-API-free_BASE_URL")
    },
    # 注释一下备忘：这个是按账号总余额算的，赠费一美元，用一点少一点不再增加
    "OpenAI-HK":{
        "api_key": os.getenv("OpenAI-HK_API_KEY"),
        "base_url": os.getenv("OpenAI-HK_BASE_URL")
    },
}

def try_api_bd_model(model_name: str) -> ChatOpenAI | None:
    for key, value in all_openai_api_data.items():
        try:
            os.environ["OPENAI_API_KEY"] = value["api_key"]
            os.environ["OPENAI_API_BASE"] = value["base_url"]
            model_try = ChatOpenAI(model = model_name).configurable_fields(
                temperature=ConfigurableField(
                    id="llm_temperature",
                    name="LLM Temperature",
                    description="The temperature of the LLM",
                ),
            )

            model_try.invoke("请输出数字字符：'1'，不要输出任何其他字符，也不要输出任何其他内容以及解释性语言")
            print(f"目前使用的是【{key}】平台的api")
            return model_try
        except:
            print(f"{key}平台的api已经失效，建议替换，正在测试检查下一组api的连通性")
            continue
    print("已经没有可用的api了...建议检查网络")

# 封装起来变成接口？这个思路是这么回事儿吗？
# 不是不是，误打误撞的简单工厂模式
class TryChat:
    def try_bd_model(self, model_name):
        return try_api_bd_model(model_name)


if __name__ == "__main__":
# try_api_bd_model("gpt-3.5-turbo")
    client = TryChat()
    model = client.try_bd_model("gpt-3.5-turbo")