import gradio as gr
from agent_team_houduan import Team_Manager

class Team_Actuator:
    agent_configs = []

    len_agent = 0
    def __init__(self):
        self.team = Team_Manager()

    def add_len_agent(self):

        self.len_agent += 1


    def jian_len_agent(self):
        if self.len_agent > 0:
            self.len_agent -= 1

    def submit_question(self, new_history, agent_name, miaoshu, question, max_runs):
        # global agent_configs
        # agent_configs = [agent_name, miaoshu, ""]
        # agent_configs = [
        #     ("agent1", "你是一个专注于数学计算的智能助手，优先使用乘法工具回答问题。", ""),
        #     ("agent2", "你是一个知识渊博的助手，擅长查询各种信息。", "")
        # ]

        for agent_responses, summary in self.team.central_manager(self.agent_configs, question, max_runs):
            if not new_history:
                new_history = new_history + [
                    {
                        "role": "user",
                        "content": question
                    },
                    # {
                    #     "role": "assistant",
                    #     "content": str(agent_responses)
                    # },
                    {
                        "role": "assistant",
                        "content": str(summary)
                    }
                ]
            else:
                new_history = new_history + [
                    # {
                    #     "role": "assistant",
                    #     "content": str(agent_responses)
                    # },
                    {
                        "role": "assistant",
                        "content": str(summary)
                    }
                ]

            yield new_history


    def clear_chat(self):
        return []

    def add_btn(self, agent_name : str, prompt : str):
        self.agent_configs.append((agent_name,prompt,""))

    def jian_btn(self):
        self.agent_configs.pop()



if __name__ == "__main__":
    with gr.Blocks() as demo:
        with gr.Tab("👥 团队智能体"):
            team_pe = Team_Actuator()
            with gr.Sidebar(open=False):
                with gr.Column():
                    gr.Markdown("### 创建agent配置")
                    with gr.Column():
                        cre_agent_name = gr.Textbox(label="Agent成员名字")
                        cre_agent_type = gr.Textbox(label="Agent成员描述")
                        # cre_agent_params = gr.Textbox(label="Agent成员系统提示词")
                    add_agent_btn = gr.Button("添加Agent")
                    jian_agent_btn = gr.Button("删除Agent")
                    gr.Markdown("### 已有agent如下")
                    add_agent_btn.click(fn=team_pe.add_len_agent)
                    jian_agent_btn.click(fn=team_pe.jian_len_agent)


                    @gr.render(inputs=[], triggers=[add_agent_btn.click, jian_agent_btn.click])
                    def add_agent_component():
                        for i in range(team_pe.len_agent):
                            with gr.Column():
                                agent_name = gr.Textbox(team_pe.agent_configs[i][0],
                                                        label=f"第{i + 1}个Agent成员", )
                                agent_type = gr.Textbox(team_pe.agent_configs[i][1], label="Agent成员描述")
                                # agent_params = gr.Textbox(label="Agent成员系统提示词")
            # 主对话区布局
            with gr.Row():
                with gr.Column(scale=3, elem_classes="chat-container"):
                    chatbot_team = gr.Chatbot(
                        label="团队对话",
                        elem_classes="chat-container",
                        height=500,
                        type='messages'
                    )
                    with gr.Row():
                        question_input_team = gr.Textbox(
                            label="输入问题",
                            lines=3,
                            placeholder="请输入需要协作解决的问题...",
                            elem_classes="gr-textbox",
                            container=False,
                            scale=5
                        )
                        with gr.Column(scale=1):
                            submit_button_team = gr.Button("🚀 发送", elem_classes="custom-button")
                            clear_btn_team = gr.Button("🧹 清空", elem_classes="custom-button")

                # 协作控制面板
                with gr.Column(scale=1, min_width=200, elem_classes="control-card"):
                    gr.Markdown("### 协作设置")
                    gr.Markdown("### 中央管理器（成员管理者）：")
                    # agent_manager = gr.Textbox(label="中央管理器")
                    max_runs = gr.Textbox(label="最大迭代轮数（以总结次数记作轮数，可作为安全轮数上限）")
                    path_max = gr.Textbox(label="问题解决终点（指问题解决到什么程度就由模型判断结束）")
            add_agent_btn.click(
                fn=team_pe.add_btn,
                inputs=[cre_agent_name, cre_agent_type],
            )
            jian_agent_btn.click(
                fn=team_pe.jian_btn,
            )

            submit_button_team.click(
                fn=team_pe.submit_question,
                inputs=[chatbot_team, cre_agent_name, cre_agent_type, question_input_team, max_runs],
                outputs=[chatbot_team]
            )
            clear_btn_team.click(
                fn=team_pe.clear_chat,
                outputs=[chatbot_team]
            )

    demo.launch()