
css_data = '''
    /* 重置Gradio界面特征，使其看起来像普通网页 */
    .gradio-container {
        max-width: 100% !important;
        padding: 0 !important;
        margin: 0 !important;
        background: #ffffff !important;
        font-family: 'SF Pro Display', 'Segoe UI', system-ui, -apple-system, BlinkMacSystemFont, sans-serif !important;
        box-shadow: none !important;
    }
    
    /* 隐藏Gradio footer */
    footer {
        display: none !important;
    }
    
    /* 隐藏Gradio品牌标识 */
    .gr-interface-title, .gr-interface-subtitle, .gradio-logo {
        display: none !important;
    }
    
    /* 侧边栏切换按钮 */
    .sidebar-toggle-btn {
        position: fixed !important;
        right: 20px !important;
        top: 80px !important;
        z-index: 1000 !important;
        width: 40px !important;
        height: 40px !important;
        border-radius: 50% !important;
        background: var(--primary-500) !important;
        color: white !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 2px 8px rgba(22, 101, 52, 0.25) !important;
        border: none !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
    }
    
    .sidebar-toggle-btn:hover {
        transform: scale(1.05) !important;
        box-shadow: 0 4px 12px rgba(22, 101, 52, 0.3) !important;
    }
    
    /* 动态标题效果 */
    .dynamic-subtitle {
        text-align: center !important;
        color: white !important;
        font-size: 1.1rem !important;
        font-weight: 400 !important;
        margin: 0 !important;
        padding: 0 !important;
        opacity: 0 !important;
        animation: fadeInOut 8s ease-in-out infinite !important;
        letter-spacing: 0.05em !important;
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        width: 100% !important;
    }
    
    .subtitle-container {
        position: relative !important;
        height: 30px !important;
        margin: 0.5rem auto !important;
    }
    
    @keyframes fadeInOut {
        0%, 5% { opacity: 0; transform: translateY(5px); }
        15%, 35% { opacity: 1; transform: translateY(0); }
        45%, 100% { opacity: 0; transform: translateY(-5px); }
    }
    
    /* 配色方案 - 现代简约风格 */
    :root {
        --primary-50: #f0fdf4;   /* 极浅绿 */
        --primary-100: #dcfce7;
        --primary-200: #bbf7d0;
        --primary-300: #86efac;
        --primary-400: #4ade80; /* 主色调 */
        --primary-500: #22c55e; /* 强调色 */
        --primary-600: #16a34a;
        --primary-700: #15803d; /* 深绿 */
        --primary-800: #166534;
        --primary-900: #14532d;
        
        --gray-50: #f9fafb;  /* 背景色 */
        --gray-100: #f3f4f6; 
        --gray-200: #e5e7eb;
        --gray-300: #d1d5db; /* 边框色 */
        --gray-400: #9ca3af;
        --gray-500: #6b7280; /* 次要文本 */
        --gray-600: #4b5563; 
        --gray-700: #374151; /* 主要文本 */
        --gray-800: #1f2937;
        --gray-900: #111827;
        
        --success: #22c55e;
        --warning: #f59e0b;
        --error: #ef4444;
        --info: #3b82f6;
    }
    
    /* 整体布局 */
    body {
        background-color: var(--gray-50) !important;
        color: var(--gray-700) !important;
        line-height: 1.5 !important;
    }
    
    /* 标签页导航样式 - 无边框底线样式 */
    .tab-nav {
        background-color: #ffffff !important;
        border-bottom: 1px solid var(--gray-200) !important;
        padding: 0 !important;
        margin: 0 !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05) !important;
        position: sticky !important;
        top: 0 !important;
        z-index: 100 !important;
    }
    
    .tab-nav button {
        padding: 1rem 1.5rem !important;
        font-weight: 500 !important;
        color: var(--gray-500) !important;
        border: none !important;
        border-radius: 0 !important;
        background: transparent !important;
        position: relative !important;
        transition: all 0.2s ease !important;
    }
    
    .tab-nav button.selected {
        color: var(--primary-600) !important;
        font-weight: 600 !important;
    }
    
    .tab-nav button.selected::after {
        content: '' !important;
        position: absolute !important;
        bottom: 0 !important;
        left: 50% !important;
        transform: translateX(-50%) !important;
        width: 30% !important;
        height: 3px !important;
        background-color: var(--primary-500) !important;
        border-radius: 3px 3px 0 0 !important;
    }
    
    .tab-nav button:hover {
        color: var(--primary-600) !important;
        background-color: var(--gray-50) !important;
    }
    
    /* 重置侧边栏样式 */
    .gradio-sidebar {
        width: 300px !important;
        background-color: #ffffff !important;
        border-right: 1px solid var(--gray-200) !important;
        padding: 1.5rem !important;
        height: 100% !important;
        box-shadow: 1px 0 5px rgba(0,0,0,0.03) !important;
        max-width: 100% !important;
        transition: all 0.3s ease !important;
    }
    
    /* 修复侧边栏内容样式 */
    .gradio-sidebar > div {
        gap: 1rem !important;
    }
    
    .gradio-sidebar label {
        margin-bottom: 0.5rem !important;
        color: var(--gray-700) !important;
        font-weight: 500 !important;
    }
    
    /* 卡片组件样式 */
    .control-card, .dashboard-panel {
        background: #ffffff !important;
        border-radius: 12px !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.04) !important;
        padding: 1.5rem !important;
        margin-bottom: 1.5rem !important;
        border: 1px solid var(--gray-200) !important;
        transition: box-shadow 0.3s ease, transform 0.3s ease !important;
    }
    
    .control-card:hover, .dashboard-panel:hover {
        box-shadow: 0 8px 25px rgba(0,0,0,0.06) !important;
        transform: translateY(-2px) !important;
    }
    
    /* 对话框样式 */
    .chat-container {
        border-radius: 12px !important;
        background: #ffffff !important;
        padding: 0 !important;
        overflow: hidden !important;
        border: 1px solid var(--gray-200) !important;
    }
    
    /* 对话气泡设计 */
    .chat-container .user, .chat-container .bot {
        max-width: 85% !important;
        padding: 1rem 1.25rem !important;
        margin: 0.75rem 1rem !important;
        border-radius: 1.5rem !important;
        line-height: 1.6 !important;
        position: relative !important;
        animation: fadeIn 0.3s ease !important;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .chat-container .user {
        background: var(--primary-500) !important;
        color: white !important;
        margin-left: auto !important;
        border-bottom-right-radius: 0.5rem !important;
    }
    
    .chat-container .bot {
        background: var(--gray-100) !important;
        color: var(--gray-800) !important;
        margin-right: auto !important;
        border-bottom-left-radius: 0.5rem !important;
    }
    
    /* 按钮样式 - 现代设计 */
    .custom-button {
        background: var(--primary-500) !important;
        color: white !important;
        font-weight: 500 !important;
        padding: 0.75rem 1.5rem !important;
        border-radius: 8px !important;
        border: none !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        box-shadow: 0 2px 5px rgba(34, 197, 94, 0.2) !important;
    }
    
    .custom-button:hover {
        background: var(--primary-600) !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(34, 197, 94, 0.3) !important;
    }
    
    /* 次要按钮 */
    button:not(.custom-button):not(.tab-nav button) {
        background: white !important;
        color: var(--gray-700) !important;
        border: 1px solid var(--gray-300) !important;
        border-radius: 8px !important;
        padding: 0.65rem 1.25rem !important;
        font-weight: 500 !important;
        transition: all 0.2s ease !important;
    }
    
    button:not(.custom-button):not(.tab-nav button):hover {
        background: var(--gray-100) !important;
        border-color: var(--gray-400) !important;
    }
    
    /* 输入框样式 */
    .gr-textbox {
        border: 1px solid var(--gray-300) !important;
        border-radius: 8px !important;
        padding: 0.75rem 1rem !important;
        transition: all 0.2s ease !important;
        background: white !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04) !important;
    }
    
    .gr-textbox:focus-within {
        border-color: var(--primary-400) !important;
        box-shadow: 0 0 0 3px rgba(74, 222, 128, 0.15) !important;
    }
    
    /* 下拉框美化 */
    .gr-dropdown {
        border: 1px solid var(--gray-300) !important;
        border-radius: 8px !important;
        background: white !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04) !important;
        transition: all 0.2s ease !important;
    }
    
    .gr-dropdown:focus-within {
        border-color: var(--primary-400) !important;
        box-shadow: 0 0 0 3px rgba(74, 222, 128, 0.15) !important;
    }
    
    /* 文件上传组件 */
    .gr-file {
        border: 2px dashed var(--gray-300) !important;
        border-radius: 12px !important;
        padding: 2.5rem 2rem !important;
        text-align: center !important;
        background: var(--gray-50) !important;
        transition: all 0.3s ease !important;
    }
    
    .gr-file:hover {
        border-color: var(--primary-400) !important;
        background: rgba(74, 222, 128, 0.05) !important;
    }
    
    .gr-file [data-testid="image"] {
        display: block !important;
        margin: 0 auto 1rem auto !important;
        max-width: 64px !important;
    }
    
    /* 复选框和单选框美化 */
    .gr-checkbox, .gr-radio {
        appearance: none !important;
        border: 1.5px solid var(--gray-400) !important;
        width: 18px !important;
        height: 18px !important;
        border-radius: 4px !important;
        margin-right: 8px !important;
        position: relative !important;
        transition: all 0.2s ease !important;
        vertical-align: middle !important;
    }
    
    .gr-checkbox:checked, .gr-radio:checked {
        background-color: var(--primary-500) !important;
        border-color: var(--primary-500) !important;
    }
    
    .gr-checkbox:checked::after {
        content: '✓' !important;
        position: absolute !important;
        color: white !important;
        font-size: 12px !important;
        left: 3px !important;
        top: -2px !important;
    }
    
    .gr-radio {
        border-radius: 50% !important;
    }
    
    .gr-radio:checked::after {
        content: '' !important;
        position: absolute !important;
        width: 8px !important;
        height: 8px !important;
        border-radius: 50% !important;
        background: white !important;
        left: 4px !important;
        top: 4px !important;
    }
    
    /* 滑块组件美化 */
    .gr-slider {
        --thumb-size: 18px !important;
        --track-height: 6px !important;
        appearance: none !important;
        height: var(--track-height) !important;
        background: var(--gray-200) !important;
        border-radius: 10px !important;
        width: 100% !important;
        outline: none !important;
        transition: all 0.2s ease !important;
    }
    
    .gr-slider::-webkit-slider-thumb {
        appearance: none !important;
        width: var(--thumb-size) !important;
        height: var(--thumb-size) !important;
        background: var(--primary-500) !important;
        border-radius: 50% !important;
        cursor: pointer !important;
        border: 2px solid white !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important;
        transition: all 0.2s ease !important;
    }
    
    .gr-slider::-webkit-slider-thumb:hover {
        transform: scale(1.1) !important;
        background: var(--primary-600) !important;
    }
    
    /* 图表容器 */
    .gr-plot-container {
        border-radius: 12px !important;
        overflow: hidden !important;
        background: white !important;
        border: 1px solid var(--gray-200) !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.04) !important;
        transition: transform 0.3s ease, box-shadow 0.3s ease !important;
    }
    
    .gr-plot-container:hover {
        transform: translateY(-3px) !important;
        box-shadow: 0 8px 25px rgba(0,0,0,0.08) !important;
    }
    
    /* 标题样式 */
    h1, h2, h3, h4, h5, h6 {
        color: var(--gray-900) !important;
        margin-top: 0.5rem !important;
        margin-bottom: 1rem !important;
        font-weight: 600 !important;
        line-height: 1.3 !important;
    }
    
    h3 {
        font-size: 1.25rem !important;
        color: var(--gray-800) !important;
        border-bottom: 1px solid var(--gray-200) !important;
        padding-bottom: 0.5rem !important;
        margin-bottom: 1.25rem !important;
    }
    
    /* 间距调整 */
    .gr-form {
        gap: 1.25rem !important;
    }
    
    .gr-block:not(.gr-box):not(.gr-form) + .gr-block:not(.gr-box):not(.gr-form) {
        margin-top: 1.25rem !important;
    }
    
    /* 响应式优化 */
    @media (max-width: 768px) {
        .gr-form {
            grid-template-columns: 1fr !important;
        }
        
        .gr-form > div {
            width: 100% !important;
        }
    }
    
    /* 页面动画效果 */
    .container {
        animation: fadeInUp 0.5s ease-out !important;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* 去除Gradio组件的默认阴影 */
    .gr-panel {
        box-shadow: none !important;
    }
    
    /* 调整行间距 */
    .gr-row {
        gap: 1.5rem !important;
        margin-bottom: 1.5rem !important;
    }
    
    /* 等高布局支持 */
    .gr-row.equal-height > .gr-col {
        height: 100% !important;
    }


'''