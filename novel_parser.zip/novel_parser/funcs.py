# 从 io 模块导入 BytesIO 类，用于在内存中处理二进制数据
from io import BytesIO
# 从 tempfile 模块导入 NamedTemporaryFile 类，用于创建临时文件
from tempfile import NamedTemporaryFile

# 从 GraphRetriever 模块导入 GraphRetriever 类，用于图数据的检索
from GraphRetriever import GraphRetriever
# 从 GraphBuilder 模块导入 GraphBuilder 类，用于构建图数据库
from GraphBuilder import GraphBuilder
# 从 GraphTalker 模块导入 GraphTalker 类，用于处理与用户的对话并生成回答
from GraphTalker import GraphTalker

def get_entities(graphretriever):
    # 假设 entities 是从 graphretriever 获取的数据
    # 使用 graphretriever 的 graph 对象执行 Cypher 查询，匹配图中所有节点并返回
    entities = graphretriever.graph.query("MATCH (n) RETURN n")
    # 初始化一个空列表，用于存储有效的实体
    valid_entities = []
    # 遍历查询返回的所有节点
    for node in entities:
        # 如果节点中不包含 "text" 字段且包含 "id" 字段
        if "text" not in node["n"] and "id" in node["n"]:
            # 将该节点的 "id" 添加到有效实体列表中
            valid_entities.append(node["n"]["id"])
    # 返回有效实体列表
    return valid_entities

# 注释掉的函数定义，原本可能是另一种获取实体的方式
# def get_entities(graphretriever: GraphRetriever) -> tuple[str, BytesIO]:
#     entities = graphretriever.graph.query("MATCH (n) RETURN n")
#     entities = [node["n"]["id"] for node in entities if "text" not in node["n"]]
#     return entities

def reset_graph(graphbuilder: GraphBuilder) -> None:
    """
    重置图数据库的索引。
    """
    # 调用 GraphBuilder 对象的 reset_graph 方法，重置图数据库
    graphbuilder.reset_graph()

def create_graph(byte_stream, graphbuilder: GraphBuilder) -> None: #-> None 表明这个函数没有返回值
    """
    根据文档创建图数据库。
    """
    # 使用 NamedTemporaryFile 创建一个临时文件，文件不会在使用后自动删除，文件后缀为 .pdf
    with NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
        # 将字节流的数据写入临时文件 byte_stream.getbuffer() 用于获取字节流对象底层的内存缓冲区视图，然后将其写入临时文件。这样做的好处是可以直接操作内存中的数据，避免了不必要的数据复制，提高了性能
        temp_file.write(byte_stream.getbuffer())
        # 调用 GraphBuilder 对象的 add_pdf_to_graph 方法，将临时文件中的 PDF 文档添加到图数据库中
        graphbuilder.add_pdf_to_graph(temp_file.name)
    # 调用 GraphBuilder 对象的 reindex_graph 方法，为图数据库创建索引
    graphbuilder.reindex_graph()

def create_response(question: str, graphretriever: GraphRetriever, graphtalker: GraphTalker)->str:
    """
    根据问题生成答案。
    """
    # 调用 GraphRetriever 对象的 create_retrieval 方法，根据问题进行检索，获取相关信息
    retrival = graphretriever.create_retrieval(question)
    # 调用 GraphTalker 对象的 create_response 方法，结合问题和检索到的信息生成回答
    response = graphtalker.create_response(question, retrival)
    # 返回生成的回答
    return response

def get_chat_history(graphtalker: GraphTalker)->list[tuple[str, str]]:
    """
    获取聊天历史。
    """
    # 调用 GraphTalker 对象的 get_chat_history 方法，获取聊天历史记录
    return graphtalker.get_chat_history()