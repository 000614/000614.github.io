from langchain_core.documents import Document  # 从langchain_core.documents模块导入Document类，用于表示文档对象
from langchain_core.prompts import ChatPromptTemplate  # 从langchain_core.prompts模块导入ChatPromptTemplate类，用于创建聊天提示模板
from langchain.text_splitter import TokenTextSplitter, RecursiveCharacterTextSplitter  # 从langchain.text_splitter模块导入TokenTextSplitter和RecursiveCharacterTextSplitter类，用于文本切分

from langchain_openai import ChatOpenAI  # 从langchain_openai模块导入ChatOpenAI类，用于与OpenAI的聊天模型进行交互
from langchain_community.document_loaders import PDFMinerLoader  # 从langchain_community.document_loaders模块导入PDFMinerLoader类，用于加载PDF文档
from langchain_community.graphs import Neo4jGraph  # 用来操作 Neo4j 图数据库的类
from langchain_experimental.graph_transformers import LLMGraphTransformer  # 使用大语言模型将文档转化为知识图谱
from langchain_deepseek import ChatDeepSeek  # 从langchain_deepseek模块导入ChatDeepSeek类，用于与DeepSeek的聊天模型进行交互
from utils import cmd_logger  # 从utils模块导入cmd_logger，可能是用于记录命令相关日志的装饰器


class GraphBuilder:
    """
    封装了从非结构化文本源构建完整知识图谱所需的核心功能。
    """

    extract_template = \
    """
你是一个从旨在从结构化格式中提取信息以构建知识图谱的顶尖算法，你的任务是的任务是识别用户提示中请求的实体和关系，并从给定文本中提取出这些信息对应的节选。。您需要以JSON格式生成输出，包含一个列表，列表中的每个元素都是一个JSON对象。每个对象应包含以下键：“head”, “head_type”, “relation”, “tail” 和 “tail_type”。

“head” 键必须包含提取实体的文本。
“head_type” 键必须包含提取的头部实体的类型。
“relation” 键必须包含 “head” 和 “tail” 之间的关系的类型。
“tail” 键应代表作为关系尾部的提取实体的文本。
“tail_type” 键必须包含尾部实体的类型。

尽可能多地提取实体和关系。并保持实体一致性：在提取实体时，确保一致性至关重要。如果文本中多次提到某个实体，例如“李华”，但使用了不同的名称或代词（例如，同事称他为“李先生”，妻子称呼他为“老李”，作者使用“他”来指代）时，请始终使用该实体的最完整标识符。知识图谱应当是连贯且易于理解的，因此保持实体引用的一致性非常关键。

最后，按照文本的语言来选择输出的语言。如果文本是中文的，就使用中文来表达实体、关系等信息，不要使用不具备意义的数字或者英文单词。

##待提取的文本##
{input}

再次强调：使用中文来表达实体、关系等信息，不要使用不具备意义的数字或者英文单词。
"""

    def __init__(self):
        self.graph = Neo4jGraph()  # 初始化Neo4jGraph对象，用于操作Neo4j图数据库
        self.extract_prompt = ChatPromptTemplate.from_template(self.extract_template)  # 根据定义的模板创建聊天提示模板

        #self.llm = ChatOpenAI(model="gpt-4o-mini")  # 使用api_key或者设置环境变量OPENAI_API_KEY
        self.llm = ChatDeepSeek(model="deepseek-chat")  # 初始化ChatDeepSeek对象，指定模型为"deepseek-chat"
        self.llm_transformer = LLMGraphTransformer(llm=self.llm, prompt=self.extract_prompt)  # 使用指定的大语言模型和提示模板初始化LLMGraphTransformer对象

    @cmd_logger  # 使用cmd_logger装饰器，可能用于记录该方法的相关日志
    def split_document_to_chunks(self, raw_docs: list[Document]) -> list[Document]:
        """
        接受从源中提取的原始文本内容，并对其应用切分算法。
        """
        # print("GraphBuilder: 开始对文档切片")
        text_splitter = TokenTextSplitter(chunk_size=128, chunk_overlap=32)  # 创建TokenTextSplitter对象，设置块大小为128，重叠部分为32
        # text_splitter = RecursiveCharacterTextSplitter(chunk_size=256, chunk_overlap=48)

        docs = text_splitter.split_documents(raw_docs)  # 使用文本切分器对原始文档进行切分
        return docs  # 返回切分后的文档列表

    @cmd_logger  # 使用cmd_logger装饰器，可能用于记录该方法的相关日志
    def add_chunks_to_graph(self, text_chunks: list[Document]) -> None:
        """
        使用 LLMGraphTransformer 将文本切片转换为图数据库文档，并写入图数据库。
        """
        batch_size = 5  # 可以根据实际情况调整，设置每次处理的文本块数量为5
        for i in range(0, len(text_chunks), batch_size):  # 按批次处理文本块
            batch = text_chunks[i:i + batch_size]  # 获取当前批次的文本块
            graph_docs = self.llm_transformer.convert_to_graph_documents(batch)  # 将当前批次的文本块转换为图数据库文档
            self.graph.add_graph_documents(
                graph_docs,
                baseEntityLabel=True,  # 表示使用基础实体标签
                include_source=True  # 表示包含源信息
            )

        # graph_docs = self.llm_transformer.convert_to_graph_documents(text_chunks)
        # # print("GraphBuilder: 开始写入图数据库")
        # self.graph.add_graph_documents(
        #     graph_docs,
        #     baseEntityLabel=True,
        #     include_source=True
        # )

    @cmd_logger  # 使用cmd_logger装饰器，可能用于记录该方法的相关日志
    def add_pdf_to_graph(self, path: str) -> None:
        """
        提供一个PDF文档，提取文本、分块文本并写入图数据库。
        """
        text_docs = PDFMinerLoader(path).load()  # 使用PDFMinerLoader加载指定路径的PDF文档，获取文本内容
        text_chunks = self.split_document_to_chunks(text_docs)  # 对加载的文本内容进行分块
        if text_chunks is not None:
            self.add_chunks_to_graph(text_docs)  # 将分块后的文本添加到图数据库中

    def reindex_graph(self) -> None:
        """
        在填充的图上创建索引，以帮助进行高效搜索。
        """
        # print("GraphBuilder: 开始创建索引")
        self.graph.query("CREATE FULLTEXT INDEX entity IF NOT EXISTS FOR (e:__Entity__) ON EACH [e.id]")  # 在图数据库中创建全文索引

    def reset_graph(self) -> None:
        """
        警告：将清空整个图，谨慎使用。
        """
        # print("GraphBuilder: 开始重置图数据库")
        self.graph.query(
            """
            MATCH (n)
            DETACH DELETE n
            """
        )  # 在图数据库中执行删除所有节点及其关系的操作