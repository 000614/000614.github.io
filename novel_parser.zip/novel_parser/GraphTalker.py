# 从 langchain_core.messages 模块导入 AIMessage 和 HumanMessage 类
# AIMessage 用于表示 AI 生成的消息，HumanMessage 用于表示人类用户的消息
from langchain_core.messages import AIMessage, HumanMessage
# 从 langchain_core.runnables 模块导入 RunnablePassthrough 类，用于定义可运行的对象
from langchain_core.runnables import RunnablePassthrough
# 从 langchain_core.prompts 模块导入 ChatPromptTemplate 类，用于创建聊天提示模板
from langchain_core.prompts import ChatPromptTemplate
# 从 langchain_core.output_parsers 模块导入 StrOutputParser 类，用于将输出解析为字符串
from langchain_core.output_parsers import StrOutputParser

# 从 langchain_openai 模块导入 ChatOpenAI 类，用于与 OpenAI 的聊天模型进行交互
from langchain_openai import ChatOpenAI
# 从 langchain_deepseek 模块导入 ChatDeepSeek 类，用于与 DeepSeek 的聊天模型进行交互
from langchain_deepseek import ChatDeepSeek
# 从 utils 模块导入 cmd_logger 函数，可能是一个日志记录装饰器
from utils import cmd_logger


class GraphTalker:

    # 定义一个字符串模板，用于根据聊天记录和用户问题改写问题
    reformulate_template = \
"""
你是一个具有能够理解问题并将问题改写的顶级算法。你需要根据以下对话和用户问题，将用户问题改写为新问题。注意：
1. 请不要反问用户，改写后的问题应该是用户可以理解的。 
2. 你的输出不应该包括聊天记录和用户的原始问题，而是只包含新问题。
3. 请确保改写后的问题与用户问题的意思一致，如果不确定用户的意思，请尽量保留原始问题。

##聊天记录##
{chat_history}
##用户问题##
{question}
"""

    # 定义一个字符串模板，用于根据参考资料和用户问题生成回答
    response_template = \
"""
你是一个具有能够理解问题并回答问题的智能机器人。你需要根据以下参考资料和用户问题，回答用户问题。注意：
1. 如果没有参考资料或参考资料信息不足，则根据你已有的知识回答该问题。使用自然语言。
2. 你的输出不应该包含参考资料和用户问题，而是只包含你最终的回答，不要反问用户。

##参考资料##
{retrieval}
##用户问题##
{question}
"""

    def __init__(self, messages=None):
        # 注释掉的代码，原本可能初始化 ChatOpenAI 对象，使用 'gpt-4o-mini' 模型
        #self.llm = ChatOpenAI(model='gpt-4o-mini')
        # 初始化 ChatDeepSeek 对象，指定使用 "deepseek-chat" 模型
        self.llm = ChatDeepSeek(model="deepseek-chat")
        # 根据 reformulate_template 创建一个聊天提示模板对象
        self.reformulate_prompt = ChatPromptTemplate.from_template(self.reformulate_template)
        # 根据 response_template 创建一个聊天提示模板对象
        self.response_prompt = ChatPromptTemplate.from_template(self.response_template)
        # 将 reformulate_prompt、llm 和 StrOutputParser 连接成一个处理链路，用于改写问题
        self.reformulate_chain = self.reformulate_prompt | self.llm | StrOutputParser()
        # 将 response_prompt、llm 和 StrOutputParser 连接成一个处理链路，用于生成回答
        self.response_chain = self.response_prompt | self.llm | StrOutputParser()

        # 如果没有传入消息列表，则初始化一个默认的消息列表，包含一条 AI 消息
        if messages is None:
            messages = [AIMessage(content="您好，我是你的智能助手，有任何问题欢迎问我!")]
        # 将消息列表存储在实例属性中
        self.messages = messages

    @cmd_logger
    def reformulate_question(self, question):
        # 获取聊天记录
        chat_history = self.get_chat_history()
        # 将聊天记录格式化为字符串，每个消息以 "角色: 内容" 的形式展示，并用换行符分隔
        chat_history = '\n'.join([f'{role}: {content}' for role, content in chat_history])
        # 调用 reformulate_chain 链路，传入用户问题和聊天记录，获取改写后的问题
        reformulated_question = self.reformulate_chain.invoke({'question': question, 'chat_history': chat_history})
        # 返回改写后的问题
        return reformulated_question

    @cmd_logger
    def create_response(self, question, retrieval):
        # 调用 reformulate_question 方法，获取改写后的问题
        reformulated_question = self.reformulate_question(question)
        # 调用 response_chain 链路，传入改写后的问题和参考资料，获取回答
        response = self.response_chain.invoke({'question': reformulated_question, 'retrieval': retrieval})
        # 将当前用户问题添加到消息列表中，作为 HumanMessage
        self.messages.append(HumanMessage(content=question)) #langchain 库中用于表示人类用户输入消息的类
        # 将生成的回答添加到消息列表中，作为 AIMessage
        self.messages.append(AIMessage(content=response)) #封装大语言模型针对人类用户输入给出的回复内容
        # 返回生成的回答
        return response

    def get_chat_history(self):
        # 初始化一个空列表，用于存储聊天记录
        chat_history = []
        # 遍历消息列表
        for message in self.messages:
            # 如果消息是 HumanMessage 类型，则将其添加到聊天记录列表中，角色为 'Human'
            if isinstance(message, HumanMessage):
                chat_history.append(('Human', message.content))
            # 如果消息是 AIMessage 类型，则将其添加到聊天记录列表中，角色为 'AI'
            elif isinstance(message, AIMessage):
                chat_history.append(('AI', message.content))
        # 返回聊天记录列表
        return chat_history