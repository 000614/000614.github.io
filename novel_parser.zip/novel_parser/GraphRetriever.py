# 从 langchain_core.prompts 模块导入 ChatPromptTemplate 类，用于创建聊天提示模板
from langchain_core.prompts import ChatPromptTemplate

# 从 langchain_openai 模块导入 ChatOpenAI 和 OpenAIEmbeddings 类
# ChatOpenAI 用于与 OpenAI 的聊天模型进行交互，OpenAIEmbeddings 用于生成文本的嵌入向量
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
# 从 langchain_community.graphs 模块导入 Neo4jGraph 类，用于操作 Neo4j 图数据库
from langchain_community.graphs import Neo4jGraph
# 从 langchain_community.vectorstores.neo4j_vector 模块导入 Neo4jVector 和 remove_lucene_chars
# Neo4jVector 用于在 Neo4j 图数据库中创建向量存储，remove_lucene_chars 用于移除 Lucene 查询中的特殊字符
from langchain_community.vectorstores.neo4j_vector import Neo4jVector, remove_lucene_chars
# 从 langchain_deepseek 模块导入 ChatDeepSeek 类，用于与 DeepSeek 的聊天模型进行交互
from langchain_deepseek import ChatDeepSeek
# 从 langchain_community.embeddings 模块导入 DashScopeEmbeddings 类，用于生成文本的嵌入向量
from langchain_community.embeddings import DashScopeEmbeddings
# 从 utils 模块导入 Entities 类和 cmd_logger 函数
# Entities 类可能用于定义实体的结构，cmd_logger 函数可能是一个日志记录装饰器
from utils import Entities, cmd_logger


class GraphRetriever:
    """
    知识谱图的构建器。
    """

    # 定义一个字符串模板，用于从文本中提取实体和关系信息，将其转换为知识图谱
    extract_template = \
"""
你正在从文本中提取对象、人物、组织或商业实体，并使用这些实体信息作为知识图谱的节点，将文档转换为知识图谱。注意：
1. 如果文本是中文的，就使用中文来表达实体、关系等信息，不要使用不具备意义的数字或者英文单词。
3. 使用规定的格式来描述并输出你所查找到的所有实体以及文档信息。


##待提取的文本##
{question}

再次强调：使用中文来表达实体、关系等信息，不要使用不具备意义的数字或者英文单词。
"""

    def __init__(self):
        # 初始化 Neo4jGraph 对象，用于与 Neo4j 图数据库进行交互
        self.graph = Neo4jGraph()
        # 初始化 ChatDeepSeek 对象，指定使用 "deepseek-chat" 模型，并将输出结构化为 Entities 类的形式
        self.llm = ChatDeepSeek(model="deepseek-chat").with_structured_output(Entities)

        #self.llm = ChatOpenAI(model="gpt-4o-mini").with_structured_output(Entities)  # 使用了with_structured_output将llm的输出结构化为Entities
        # 根据 extract_template 创建一个聊天提示模板对象
        self.extract_prompt = ChatPromptTemplate.from_template(self.extract_template)
        # 将聊天提示模板和大语言模型绑定成一个处理链路，方便后续调用
        #“链路（Chain）” 是一种设计模式或编程概念，它把多个组件按照特定顺序连接起来，让数据能依次经过这些组件进行处理，最终得到期望的输出
        self.entity_extract_chain = self.extract_prompt | self.llm  # 将模板和llm绑定成链路

    def create_retrieval(self, question: str) -> str:
        """
        基于用户的问题，图 RAG 检索器将结构化和非结构化检索方法结合到一个检索器中。
        """
        # 调用 create_unstructured_retrieval 方法进行非结构化数据检索，返回与问题相关的文档列表
        unstructured_data = self.create_unstructured_retrieval(question)  # 非结构化数据：直接按照相似度排序-返回结果（字符串组成的列表）
        # 调用 create_structured_retrieval 方法进行结构化数据检索，返回与问题相关的关系信息列表
        structured_data = self.create_structured_retrieval(question)  # 结构化查询：用户输入-实体列表-对每一个实体查询-返回结果（字符串组成的列表）
        # 将非结构化数据和结构化数据合并成一个格式化的字符串
        final_data = \
"""
##非结构化数据查询结果##
{}

##结构化数据查询结果##
{}
""".format("\n##文档：".join(unstructured_data),"\n".join(structured_data))
        # 返回合并后的结果
        return final_data

    @cmd_logger
    def create_unstructured_retrieval(self, question: str) -> list[str]:
        """
        创建一个检索器，使用图数据库中的向量表示来检索与用户问题相关的文档。

        参数:
            question (str): 用户提出的问题

        返回:
            List[str]: 与用户问题相关的文档的列表
        """
        # print("GraphRetriever: 开始非结构化数据检索")
        # self.get_vector_index()获取向量索引对象，并使用similarity_search相似度搜索方法查找与问题相关的文档，提取文档的页面内容
        unstuctured_data = [document.page_content for document in self.get_vector_index().similarity_search(question)]
        # 过滤掉空文档，并移除文档中的换行符
        unstuctured_data = [document.replace('\n', '') for document in unstuctured_data if document]  # 过滤掉空文档
        # 返回处理后的非结构化数据列表
        return unstuctured_data


    def get_vector_index(self) -> Neo4jVector:
        # 初始化 DashScopeEmbeddings 对象，指定使用 "text-embedding-v3" 模型，并设置 API 密钥
        embeddings = DashScopeEmbeddings(
            model="text-embedding-v3", dashscope_api_key="sk-eb40ccf62d6648dc92a16ecff1686efa"
        )

        """
        使用现有图创建向量数据库。使用 DashScopeEmbeddings。
        #使用现有图创建向量数据库。使用 OpenAIEmbeddings。
        """
        # 从现有的图数据库中创建一个向量索引对象，使用指定的嵌入模型、搜索类型、节点标签等信息
        vector_index = Neo4jVector.from_existing_graph(
            embeddings,
            #OpenAIEmbeddings(),
            search_type="hybrid",  # 结合多种搜索方法（例如全文搜索和图数据库查询）来提高检索结果的准确性和效率
            node_label="Document", #该参数指定了图数据库中节点的标签为 "Document"
            # 此参数指定了节点中包含文本信息的属性名称为 "text"。在创建向量索引时，会从具有 "Document" 标签的节点的 "text" 属性中获取文本内容，用于生成嵌入向量
            text_node_properties=["text"],
            #这个参数指定了节点中存储嵌入向量的属性名称为 "embedding"。创建向量索引后，生成的嵌入向量会存储在节点的 "embedding" 属性中，以便后续进行相似性搜索等操作。
            embedding_node_property="embedding"
        )
        # 返回创建好的向量索引对象
        return vector_index

    @cmd_logger
    def create_structured_retrieval(self, question: str) -> str:
        """
        创建一个检索器，使用从用户查询中提取的实体从图中请求上下文，并返回与该查询相关的相邻节点和边。
        """
        # 注释掉的代码，原本可能用于打印开始结构化数据检索的日志
        # print("GraphRetriever: 开始结构化数据检索")
        # 调用 entity_extract_chain 链路，根据用户问题提取实体列表
        entities = self.entity_extract_chain.invoke({"question": question})
        # 初始化一个空列表，用于存储所有的关系信息
        all_relations = []
        # 遍历提取到的实体列表
        for entity in entities.names:
            # 调用 create_full_text_query 方法，为当前实体生成全文搜索查询字符串
            query = self.create_full_text_query(entity)
            # 在图数据库中执行查询，查找与当前实体相关的关系信息
            relations = self.graph.query(  # List[Dict[str, Any]]
                """CALL db.index.fulltext.queryNodes('entity', $query, {limit:2})
                YIELD node,score
                CALL {
                WITH node
                MATCH (node)-[r]->(neighbor)
                RETURN node.id + ' - ' + type(r) + ' -> ' + neighbor.id AS output
                UNION ALL
                WITH node
                MATCH (node)<-[r]-(neighbor)
                RETURN neighbor.id + ' - ' + type(r) + ' -> ' +  node.id AS output
                }
                RETURN output LIMIT 50
                """,
                params={"query": query},
            )
            # 将查询到的关系信息添加到 all_relations 列表中
            all_relations.extend(relations)
        # 将存储关系信息的字典列表转换为字符串列表
        all_relations = [relation["output"] for relation in all_relations]  # 把字典列表转化为字符串列表
        # 返回处理后的关系信息列表
        return all_relations

    def create_full_text_query(self, entity: str) -> str:
        """
        生成给定输入字符串的全文搜索查询。
        此函数构建适合全文搜索的查询字符串。它通过将输入字符串拆分为单词，并为每个单词附加相似度阈值（约 2 个字符变化），然后使用 AND 操作符
        将它们组合起来。用于将用户问题中的实体映射到数据库值，并允许拼写错误。
        """
        # 初始化一个空字符串，用于存储最终的全文搜索查询字符串
        full_text_query = ""

        # 拆分输入字符串为单词，并移除其中为查询保留的特殊字符，过滤掉空单词
        words = [word for word in remove_lucene_chars(entity).split() if word]

        # 为每个单词添加相似度阈值（约 2 个字符变化）
        words = [word+'~2' for word in words]
        # 使用 AND 操作符将处理后的单词连接成一个完整的查询字符串
        full_text_query = " AND ".join(words)
        # 移除查询字符串两端的空白字符，并返回结果
        return full_text_query.strip()