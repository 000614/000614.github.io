import time
from langchain_core.pydantic_v1 import BaseModel, Field
# BaseModel 用于定义Pydantic模型
# Field 用于定义该模型字段的元数据？

class Entities(BaseModel):
    #使用Field存储的描述，通常可以用参数限定的更准确点
    names: list[str] = Field(
        description = "文本中出现的所有物体、人物、组织或商业实体，使用中文表达。"
    )

#做一个装饰器函数方便调试
def cmd_logger(func):
    def wrapper(self, *args, **kwargs):
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}:{self.__class__.__name__:<20s}:{func.__name__:<20s}")
        result = func(self, *args, **kwargs)
        return result
    return wrapper