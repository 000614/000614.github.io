import sys
import subprocess
import os
import streamlit as st
import funcs
from GraphBuilder import GraphBuilder   # 据说是构建图的
from GraphRetriever import GraphRetriever   # 据说是检索图的
from GraphTalker import GraphTalker         # 据说是和图数据对话的
import time
from neo4j import GraphDatabase

def main():

    #   用extracted_files记录已导入数据库的文件
    if "extracted_files" not in st.session_state:
        st.session_state.extracted_files = []

    st.set_page_config(page_title = "拆书机器人", layout = "wide")
    st.title("图数据库拆书助手")#组件

    with st.sidebar:#容器
        st.header("Graph 管理")#组件
        #组件
        uploaded_file = st.sidebar.file_uploader(
            label = "上传pdf文件", type = ["pdf"]
        )
        #容器
        col1, col2 = st.columns(2)
        #容器
        with col1:
            response = st.button("解析pdf导入数据库")
            if response:#click事件
                #检查是否已经导入过，避免重复解析
                if uploaded_file and (uploaded_file.name not in st.session_state.extracted_files):
                    waiting = st.empty()
                    waiting.info("正在解析并导入...")
                    funcs.create_graph(uploaded_file, st.session_state.graphbuilder)
                    #更新已导入的记录
                    st.session_state.extracted_files.append(uploaded_file.name)
                    waiting.success("导入图数据库成功")
                    waiting.empty()
                else:
                    st.info("文件名为空！或者已经导入过该文件，请尝试更换同名文件")

        with col2:
            response = st.button("清空以重新导入")
            if response:
                waiting = st.empty()
                waiting.info("正在清空导入记录（也会清空数据库！）")
                funcs.reset_graph(st.session_state.graphbuilder)
                st.session_state.extracted_files = []
                waiting.success("Graph 重置成功")
                waiting.empty()

        entities = funcs.get_entities(st.session_state.graphretriever)
        if entities:
            st.text_area("实体列表", '\n'.join(entities), height = 200)
        else:
            st.info("未创建")

    question = st.chat_input("输入问题提问....")
    if question is not None and question != "":
        with st.spinner("稍等，正在准备回答..."):
            funcs.create_response(question, st.session_state.graphretriever, st.session_state.graphtalker)

    chat_history = funcs.get_chat_history(st.session_state.graphtalker)
    for chat in chat_history:
        role, content = chat
        with st.chat_message(role):
            st.write(content)



def wait_for_neo4j_ready(max_retries=20, delay=0.1):
    uri = os.getenv("NEO4J_URI")
    auth = (os.getenv("NEO4J_USERNAME"), os.getenv("NEO4J_PASSWORD"))
    driver = GraphDatabase.driver(uri, auth=auth)
    for _ in range(max_retries):
        try:
            driver.verify_connectivity()
            driver.close()
            print("Neo4j 已就绪！")
            return True
        except Exception as e:
            print(f"正在循环检测：数据库启动是否完成（如超时请检查密码）")
            time.sleep(delay)
    print("链接数据库寄了，请检查密码")
    return False

#多加了几行，可以直接run了
if __name__ == "__main__":
    os.environ["NEO4J_URI"] = "bolt://localhost:7687"
    os.environ["NEO4J_USERNAME"] = "neo4j"
    # 我的密码比较特别，当天请假上线上，自己设置数据库密码设置快了...
    os.environ["NEO4J_PASSWORD"] = "DINGZIJIAN"

    #这里用项目环境变量的状态来记录是否是streamlib启动的
    if "STREAMLIT_RUNNING" not in os.environ:
        #这里数据库启动写在这个位置不太好，因为如果别人没有run本文件
        #而是直接用streamlit指令启动这个py主文件，就会把这里的neo4j启动一起跳过了...
        #可以考虑直接把neo4j启动 写进main方法里面，如果嫌乱的话再分一层if判断也行，这里先不改了
        #还得改改，要确保图数据库启动完成，再打开程序连接数据库的先后顺序...还得加个wait函数验证数据库是否启动成功
        try:
            neo4j_process = subprocess.Popen('start cmd.exe /k "neo4j.bat console"', shell = True)
            print("正在从外部打开cmd，自动执行neo4j.bat console中....")
        except Exception as e:
            print(f"启动neo4j失败了，错误{e}")
        if not wait_for_neo4j_ready():
            sys.exit(1)  # 若超时，终止程序

        # 将启动状态记录，改为终端指令启动（一定一定一定要放在子程序启动前，大坑）
        os.environ["STREAMLIT_RUNNING"] = "1"
        #这里直接无头的方式指令启动
        subprocess.run([sys.executable, "-m", "streamlit", "run", __file__])


        sys.exit() # 父进程（父进程是第一次执行程序的进程）退出，由子进程（子进程是subprocess.run出来的进程）接管

    else:

        os.environ["DEEPSEEK_API_KEY"] = "sk-19a6e044d00c4962b62434ec87302a87"
        os.environ["DEEPSEEK_API_BASE"] = "https://api.deepseek.com"

        #也是用started键 来作为是否需要初始化的标识，避免反复初始化
        if "started" not in st.session_state:
            st.session_state.started = True
            st.session_state.graphbuilder = GraphBuilder()
            st.session_state.graphretriever = GraphRetriever()
            st.session_state.graphtalker = GraphTalker()


        #也是画上图了,绘制还是放main里面
        main()

